package ibnk.dto.BankingDto.TransferModel;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.RequiredArgsConstructor;

@Data
@NoArgsConstructor
public class MomoSchemaType {
    public String phoneNumber;

}
