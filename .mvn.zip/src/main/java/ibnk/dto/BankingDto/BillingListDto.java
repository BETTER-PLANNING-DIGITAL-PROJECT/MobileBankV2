package ibnk.dto.BankingDto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.sql.Types;
import java.util.Map;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class BillingListDto {
    @JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
    private String Pd_ServerDate;
    @JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
    private String Pc_PrincipAccount;
    @JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
    private String Pc_SlaveAccount;
    @JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
    private String Pc_TypeOp;
    @JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
    private String Pc_CodeOp;
    @JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
    private float SvMontant;
    @JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
    private String SvParaTx;
    @JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
    private String Language;
    private String ErrMsg;
    private int lect;
    private Object retAmount;
    private Object mntTva;

    public static BillingListDto modeltodto(Map<String, Object> map){
        BillingListDto billingListDto = new BillingListDto();
        billingListDto.setLect((Integer) map.get("lect"));
        billingListDto.setErrMsg((String) map.get("ErrMsg"));
        billingListDto.setMntTva( map.get("MntTva"));
        billingListDto.setRetAmount( map.get("RetAmount"));
        return billingListDto;
    }
}
