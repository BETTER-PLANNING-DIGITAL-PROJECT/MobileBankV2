package ibnk.dto.BankingDto;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.sql.ResultSet;
import java.sql.SQLException;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AccountEntityDto {
        private String AccountID;
        private String AccountName;
        private String ProductType;
        private String ACStatus;
        private String ClientName;
        private String ClientPrenom;
        private String Adresse1;
        private String ClientID;
        private String ClientType;
        private String client;
        private String Mobile;
        private String Phone1;
        private String email;
        private String Eaccount;
        private String MobileType;
        @JsonIgnore
        private String passwordOperation;
        private Integer outStatus;

        private String outMessage;

        private String OurBranchID;

        private String BranchName;

        private String ProductID;

        private Double availableBalance;

        private int photoId;

        public static AccountEntityDto modelToDao(AccountEntityDto account, ResultSet map) throws SQLException {
                account.setProductType(map.getString("ProductType"));
                account.setClient(map.getString("client"));
                account.setEmail(map.getString("email"));
                account.setClientID(map.getString("client"));
                account.setClientName(map.getString("NomJumelle"));
                account.setClientPrenom(map.getString("Prenom"));
                account.setAdresse1(map.getString("Adresse1"));
                account.setClientType(map.getString("TypeClient"));
                account.setMobile(map.getString("Telephone1"));
                account.setPhone1(map.getString("Telephone2"));
                account.setAccountID(map.getString("CpteJumelle"));
                account.setACStatus(map.getString("Statut"));
                account.setProductID(String.valueOf(map.getInt("CatCpte")));
                account.setAccountName(map.getString("LibCatCpte"));
                account.setOurBranchID(map.getString("Agence"));
                account.setBranchName(map.getString("LibAgence"));
                account.setPasswordOperation(map.getString("passwordOperation"));
                account.setMobileType(map.getString("MobileType"));
                account.setEaccount(map.getString("Eaccount"));
                return account;
        }



}
