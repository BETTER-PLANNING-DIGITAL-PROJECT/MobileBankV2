package ibnk.dto.BankingDto;

import ibnk.models.client.ClientSecurityQuestion;
import ibnk.models.client.SecurityQuestions;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotEmpty;
import lombok.Data;

import java.util.List;

@Data
public class ClientQuestDto{
        private Long id;
        private Long securityQuestionId;
        private String securityAns;
}
