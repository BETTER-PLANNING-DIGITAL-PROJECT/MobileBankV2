package ibnk.dto.BankingDto;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class SearchDataBillDto {
    private String id;

    private String typeOp;

}
