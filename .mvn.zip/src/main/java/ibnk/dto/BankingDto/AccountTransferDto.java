package ibnk.dto.BankingDto;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.sql.SQLException;
import java.util.Map;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AccountTransferDto {
    @JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
    private String accountId;
    @JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
    private String beneficiary_account;
    @JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
    private String memo;
    @JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
    private String ids;
    @JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
    private String date;
    @JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
    private float amount;
    @JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
    private String client;
    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    private String id_transaction;
    @JsonIgnore
    private int pc_OutLECT;
    @JsonIgnore
    private String pc_OutMSG;

    public static AccountTransferDto modelToDao(Map<String, Object> map) throws SQLException {
        AccountTransferDto accountTransferDto = new AccountTransferDto();
        accountTransferDto.setPc_OutLECT((Integer) map.get("pc_OutLECT"));
        accountTransferDto.setPc_OutMSG((String) map.get("pc_OutMSG"));
        accountTransferDto.setId_transaction((String) map.get("pc_OutID"));
        return accountTransferDto;
    }

    public static AccountTransferDto TransferToDao(Map<String, Object> map)  {
        AccountTransferDto accountTransferDto = new AccountTransferDto();
        accountTransferDto.setPc_OutLECT((Integer) map.get("pc_OutLECT"));
        accountTransferDto.setPc_OutMSG((String) map.get("pc_OutMSG"));
        return accountTransferDto;
    }


}
