package ibnk.dto.BankingDto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.sql.ResultSet;
import java.sql.SQLException;
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AccountHistoryDto {
    private double credit;
    private double debit;
    private String valueDate;
    private String operationDate;
    private String accountID;
    private String accountName;
    private Integer index;
    private String reference;
    private String description;
    private double closingBalance;

    public static AccountHistoryDto modelToDao(AccountHistoryDto account, ResultSet map, double closingBalance) throws SQLException {
        account.setCredit(map.getDouble("Credit"));
        account.setDebit(map.getDouble("Debit"));
        account.setValueDate( map.getString("DateValeur"));
        account.setOperationDate(map.getString("DateOperation"));
        account.setReference(map.getString("Txnno"));
        account.setAccountID(map.getString("CpteJumelle"));
        account.setAccountName(map.getString("LibProduct"));
        account.setIndex(map.getInt("serie"));
        account.setClosingBalance(closingBalance);
        account.setDescription(map.getString("Description"));
        return account;
    }
}
