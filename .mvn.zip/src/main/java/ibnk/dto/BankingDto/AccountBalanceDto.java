package ibnk.dto.BankingDto;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Map;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AccountBalanceDto {

    //    @ws_SenderAccount nvarchar (11) ,
    @JsonIgnore
    private int pc_OutLECT;
    @JsonIgnore
    private String pc_OutMSG;
    private Double validBalance;
    private Double clearBalance;
    private Double availableBalance;
    private String name;
    private String cni;
    private String client;
    private String telephone1;
    private String telephone2;

    public static AccountBalanceDto modelToDao(Map<String, Object> map) {
        AccountBalanceDto account = new AccountBalanceDto();
        account.setPc_OutLECT((Integer) map.get("pc_OutLECT"));
        account.setPc_OutMSG((String) map.get("pc_OutMSG"));
        account.setValidBalance((Double) map.get("pc_SoldeValide"));
        account.setClearBalance((Double) map.get("pc_SoldeReel"));
        account.setAvailableBalance((Double) map.get("pc_SoldeDisponible"));
        account.setName((String) map.get("pc_Nom"));
        account.setCni((String) map.get("pc_CNI"));
        account.setClient((String) map.get("pc_Client"));
        account.setTelephone1((String) map.get("pc_Telephone1"));
        account.setTelephone2((String) map.get("pc_Telephone2"));
        return account;
    }

}
