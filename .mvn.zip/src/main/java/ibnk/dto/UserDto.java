package ibnk.dto;

import com.fasterxml.jackson.annotation.JsonIgnore;
import ibnk.models.client.Subscriptions;
import ibnk.models.UserEntity;
import ibnk.models.enums.OtpChanel;
import ibnk.models.enums.UserTypeEnum;
import lombok.Data;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDateTime;

@Data
public class UserDto {


    @Data
    public static class CreateUserDto {
        private String userLogin;
        private Long userRoleId;
        private String password;
        private String status;
        private String confirm_password;
        private Boolean passExpiration;
        private Long passDuration;
        private String passPeriodicity;

        public static CreateUserDto modelToDao(UserEntity model) {
            CreateUserDto cus = new CreateUserDto();
            cus.setUserLogin(model.getUsername());
            return cus;
        }

        public static UserEntity DtoToModel(CreateUserDto dto) {
            UserEntity cus = new UserEntity();
            cus.setUserLogin(dto.getUserLogin());
            cus.setPassword(dto.getPassword());
            cus.setPassExpiration(dto.getPassExpiration());

            return cus;
        }
    }

    @Data
    public static class CreateSubscriberClientDto {

        private Long id;
        private String uuid;
        private String  subscriptionDate;
        private String email;
        private String name;
        private String userLogin;
        private Boolean firstLogin;
        private Integer securityQuestionCounts;
        private String primaryAccount;
        private String productName;
        private String clientMatricule;
        private String preferredOtpChannel;
        private String phoneNumber;
        private String userName;
        private Long subscriberBy;
        @JsonIgnore
        private String password;
        private Boolean passExpiration;
        private Long passDuration;
        private String passPeriodicity;
        private Boolean isPasswordExpired;
        private LocalDateTime passwordExpiredDate;
        private String address;
        private Boolean doubleAuthentication;

        public static CreateSubscriberClientDto modelToDao(Subscriptions model) {
            CreateSubscriberClientDto dto = new CreateSubscriberClientDto();
            dto.setName(model.getClientName());
            dto.setProductName(model.getProductName());
            dto.setUserLogin(model.getUserLogin());
            dto.setFirstLogin(model.getFirstLogin());
            dto.setClientMatricule(model.getClientMatricul());
            dto.setPrimaryAccount(model.getPrimaryAccount());
            dto.setPhoneNumber(model.getPhoneNumber());
            dto.setUserName(model.getUserLogin());
            dto.setEmail(model.getEmail());
            dto.setId(model.getId());
            dto.setUuid(model.getUuid());
            dto.setSubscriptionDate(model.getSubscriptionDate());
            dto.setAddress(model.getAddress());
            dto.setDoubleAuthentication(model.getDoubleAuthentication());
            dto.setPasswordExpiredDate(model.getPassExpirationDate());
            dto.setIsPasswordExpired(model.isPasswordExpired());
            dto.setPassExpiration(model.getPassExpiration());
            dto.setPassPeriodicity(model.getPassPeriodicity());
            dto.setPassDuration(model.getPassDuration());
            dto.setPreferredOtpChannel(model.getPreferedOtpChanel().name());
            //dto.setIsPasswordExpired(model.getI);

            return dto;
        }
        public static Subscriptions DtoToModel(UserDto.CreateSubscriberClientDto dto) {
            Subscriptions MDL = new Subscriptions() ;
            MDL.setClientName(dto.getName());
            MDL.setProductName(dto.getProductName());
            MDL.setClientMatricul(dto.getClientMatricule());
            MDL.setPrimaryAccount(dto.getPrimaryAccount());
            MDL.setPassword(dto.password);
            MDL.setId(dto.getId());
            MDL.setUuid(dto.getUuid());
            MDL.setSubscriptionDate(dto.getSubscriptionDate());
            MDL.setPhoneNumber(dto.getPhoneNumber());
            MDL.setUserLogin(dto.getUserName());
            MDL.setEmail(dto.getEmail());
            MDL.setPassExpiration(dto.getPassExpiration());
            MDL.setDoubleAuthentication(dto.getDoubleAuthentication());
            MDL.setPreferedOtpChanel(OtpChanel.valueOf(dto.getPreferredOtpChannel()));
            return MDL;
        }

    }

    @Data
    public static class EmployeeDto {
        private String employeeId;

        private String branch;

        private String employeeName;

        private String quality;

        private String status;

        private boolean suspension;
        public static EmployeeDto DtoToModel(ResultSet map) throws SQLException {
            EmployeeDto model = new EmployeeDto();
            model.setBranch(map.getString("Agence"));
            model.setEmployeeId(map.getString("Matricule"));
            model.setEmployeeName(map.getString("NomPrenom"));
            model.setQuality(map.getString("LibQualite"));
            model.setStatus(map.getString("Status"));
            model.setSuspension(map.getBoolean("Suspension"));
            return model;
        }
    }



    //

}