package ibnk.dto.auth;

import ibnk.models.enums.OtpEnum;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class OtpAuth {
    private int otp;
    private String role;
}