package ibnk.dto;

import ibnk.models.client.ClientSecurityQuestion;
import lombok.Data;

import java.util.List;

@Data
public class SubscriptionDao {
    private String accountId;
    private String userLogin;
    private String packageCode;
    private Integer applyFee;

}
