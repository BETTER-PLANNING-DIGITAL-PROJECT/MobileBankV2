package ibnk.dto;

import ibnk.models.enums.EventCode;
import lombok.Data;

@Data
public class EventObjectDto {
    private EventCode eventCode;
    private Object payLoad;
}
