package ibnk.tools.nexaConfig;

import lombok.RequiredArgsConstructor;
import org.json.JSONObject;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.*;
import org.springframework.scheduling.annotation.Async;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.reactive.function.client.WebClient;

import java.util.concurrent.CompletableFuture;

@RequiredArgsConstructor
@Configuration
public class NexaService {
    private String URL = "https://smsvas.com/bulk/public/index.php/api/v1/sendsms";
    static final String Username = "global.wallet@betterplanning.net";
    static final String Password = "GlobalWallet";
    // private final WebClient webClient = new WebClient();
    private final RestTemplate RestNexa = new RestTemplate();

    // private final HttpPost request = new HttpPost(URL);

    // private HttpHeaders header() {
    // HttpHeaders header = new HttpHeaders();
    // String UserNamePassword = "global.wallet@betterplanning.net:GlobalWallet";
    // byte[] encoder = Base64.encodeBase64(UserNamePassword.getBytes());
    // String base64String = "Basic " + new String(encoder);
    // header.set(HttpHeaders.AUTHORIZATION, base64String);
    // header.set(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE);
    // return header;
    // }

    // @CrossOrigin("* ")
    @Async()
    public CompletableFuture<Boolean> SendSms(NexaResponse nexaResponse)  {
        nexaResponse.setPassword(Password);
        nexaResponse.setUser(Username);
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        JSONObject map = new JSONObject(nexaResponse);
        HttpEntity<String> request = new HttpEntity<>(map.toString(), headers);
        try {
            var response = RestNexa.exchange(URL, HttpMethod.POST, request, String.class);
            System.out.println(response);
            return CompletableFuture.completedFuture(true);
        } catch (Exception ex) {
            System.out.println("Network Error Occured Make sure your Connected: " + ex.getMessage());
        }
        return CompletableFuture.completedFuture(false);
    }

    @Async
    public CompletableFuture<Boolean> LessSms(NexaResponse nexaResponse) {
        nexaResponse.setPassword(Password);
        nexaResponse.setUser(Username);
        RestTemplate restTemplate = new RestTemplate();
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        JSONObject request = new JSONObject(nexaResponse);
        HttpEntity<String> entity = new HttpEntity<String>(request.toString(), headers);
        String url = URL;
        ResponseEntity<String> response = restTemplate.postForEntity(url, entity, String.class);
        System.out.println(response);
        return CompletableFuture.completedFuture(true);
    }
    @Async
    public CompletableFuture<Boolean> WebSms(NexaResponse nexaResponse) {
        nexaResponse.setPassword(Password);
        nexaResponse.setUser(Username);
        JSONObject map = new JSONObject(nexaResponse);
        try {
            Object responsObject = WebClient.builder()
                    .baseUrl(URL)
                    .defaultHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
                    .build()
                    .post()
                    .bodyValue(map)
                    .retrieve()
                    .toEntity(Object.class);
            System.out.println(responsObject);
            return CompletableFuture.completedFuture(true);
        }catch (Exception ex){
            System.out.println("Network Error Occurred Make sure your Connected: " + ex.getMessage());
            return CompletableFuture.completedFuture(false);
        }
    }
}
