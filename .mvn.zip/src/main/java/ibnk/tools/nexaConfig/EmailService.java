package ibnk.tools.nexaConfig;

import ibnk.dto.BankingDto.BillingListDto;
import ibnk.dto.EventObjectDto;
import ibnk.dto.auth.AuthDto;
import ibnk.models.InstitutionConfig;
import ibnk.models.NotificationTemplate;
import ibnk.models.enums.EventCode;
import ibnk.repository.NotificationTemplateRepository;
import ibnk.service.InstitutionConfigService;
import ibnk.tools.error.ResourceNotFoundException;
import ibnk.tools.response.AuthResponse;
import jakarta.mail.MessagingException;
import jakarta.mail.internet.InternetAddress;
import jakarta.mail.internet.MimeMessage;
import lombok.RequiredArgsConstructor;
import org.springframework.context.ApplicationEvent;
import org.springframework.context.event.EventListener;
import org.springframework.core.env.ConfigurableEnvironment;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import java.util.Properties;
import java.util.concurrent.CompletableFuture;

@Service
@RequiredArgsConstructor
public class EmailService {
    private final JavaMailSender emailSender;
    private final JavaMailSenderImpl javaMailSender;
    private final InstitutionConfigService institutionConfigService;
    private final NotificationTemplateRepository notificationTemplateRepository;
    private final ConfigurableEnvironment environment;
    public InstitutionConfig instConfig() throws ResourceNotFoundException {
        return  institutionConfigService.listConfig();
    }

    public void javaMailSender() throws ResourceNotFoundException {

        // Fetch email configurations from the database
        javaMailSender.setHost(instConfig().getHost());
        javaMailSender.setPort(Math.toIntExact(instConfig().getPort()));
        javaMailSender.setUsername(instConfig().getInstitutionEmail());
        javaMailSender.setPassword(instConfig().getEmailPassword());

        Properties props = javaMailSender.getJavaMailProperties();
        props.put("mail.transport.protocol", "smtp");
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.starttls.enable", "true");


    }
//    public void setSpringEmailProperty() throws ResourceNotFoundException {
//        MutablePropertySources propertySources = environment.getPropertySources();
//        Properties props = new Properties();
//        props.put("spring.mail.username", instConfig().getInstitutionEmail());
//        props.put("spring.mail.password", instConfig().getEmailPassword());
//        propertySources.addLast(new PropertiesPropertySource("emailProperties", props));
//    }

    @Async
    public CompletableFuture<String> sendSimpleMessage(String to, String subject, String text)  {
        try {
            javaMailSender();
            MimeMessage message = emailSender.createMimeMessage();
//            message.setContent(text,"text/html");
            MimeMessageHelper helper = new MimeMessageHelper(message, true); // true indicates multipart message        message.setFrom("noreply@baeldung.com");
            helper.setTo(to);
            helper.setFrom(new InternetAddress(instConfig().getInstitutionEmail(),"Internet-Banking"));
            helper.setSubject(subject);
            helper.setText(text,true);
            emailSender.send(message);
        } catch (Exception e) {
            System.out.println("wwwwwwwwwwwwwwwwwwwwwwwwwwwww: emaill error             ");
            return CompletableFuture.completedFuture(null);
        }
        return CompletableFuture.completedFuture("Success");
    }

    @EventListener
    public void handleCustomEvent(EventObjectDto event) throws ResourceNotFoundException {

//        if (event.getEventCode().equals(EventCode.FIRST_LOGIN)) {
//            NotificationTemplate template = notificationTemplateRepository.findByIdAndNotificationType()
//            System.out.println("Received custom event: " + event.getUserDao());
//            sendSimpleMessage("","","");
//
//            // Access properties of AuthDto
//
//            // Handle the event
//
//        }
    }
}
