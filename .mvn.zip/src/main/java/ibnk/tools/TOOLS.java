package ibnk.tools;

import ibnk.models.client.Subscriptions;
import ibnk.tools.jwtConfig.MobileJwt;
import lombok.Data;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.YearMonth;
import java.time.temporal.TemporalAdjusters;
import java.util.*;

public class TOOLS {

    public static LocalDateTime Expiration() {
        LocalDateTime now = LocalDateTime.now();
        // add 10 minutes to the current date and time
        return now.plusMinutes(3);

    }

    public static String generateAccessToken(Subscriptions client) throws Exception {

        MobileJwt jwt = new MobileJwt();
        return jwt.generateJwtToken(client);
    }

    public static void addError(List<Map<String, String>> errors, String key, String value) {
        Map<String, String> error = new HashMap<>();
        error.put(key, value);
        errors.add(error);
    }

    public static LocalDate firstDayOfThisMonth() {
        // Get the current date
        LocalDate currentDate = LocalDate.now();

        // Get the first date of the current month
        LocalDate firstDateOfMonth = currentDate.withDayOfMonth(1);

        System.out.println("First date of the current month: " + firstDateOfMonth);
        return firstDateOfMonth;
    }

    public static LocalDate firstDayOfPreviousMonth() {
        YearMonth currentYearMonth = YearMonth.now();
        YearMonth previousYearMonth = currentYearMonth.minusMonths(1);
        LocalDate firstDateOfPreviousMonth = previousYearMonth.atDay(1);

        System.out.println("First date of the previous month: " + firstDateOfPreviousMonth);
        return firstDateOfPreviousMonth;
    }

    public static LocalDate lastDayOfPreviousMonth() {
        // Get the current YearMonth
        YearMonth currentYearMonth = YearMonth.now();
        // Subtract one month to get the previous YearMonth
        YearMonth previousYearMonth = currentYearMonth.minusMonths(1);
        // Get the last date of the previous month
        LocalDate lastDateOfPreviousMonth = previousYearMonth.atEndOfMonth();
        System.out.println("Last date of the previous month: " + lastDateOfPreviousMonth);
        return lastDateOfPreviousMonth;
    }

    public static LocalDate firstDayOfPreviousQuarterMonth() {
        LocalDate currentDate = LocalDate.now();
        YearMonth currentYearMonth = YearMonth.from(currentDate);

        // Calculate the first day of the current quarter
        LocalDate firstDayOfCurrentQuarter = currentYearMonth
                .atDay(1)
                .with(TemporalAdjusters.firstDayOfMonth());

        // Calculate the first day of the previous quarter
        LocalDate firstDayOfPreviousQuarter = firstDayOfCurrentQuarter
                .minusMonths(3);

        System.out.println("First day of the previous quarter: " + firstDayOfPreviousQuarter);
        return firstDayOfPreviousQuarter;
    }

    public static LocalDate lastDayOfPreviousQuarterMonth() {
        LocalDate currentDate = LocalDate.now();
        YearMonth currentYearMonth = YearMonth.from(currentDate);

        // Calculate the first day of the current quarter
        LocalDate firstDayOfCurrentQuarter = currentYearMonth
                .atDay(1)
                .with(TemporalAdjusters.firstDayOfMonth());

        // Calculate the last day of the previous quarter
        LocalDate lastDayOfPreviousQuarter = firstDayOfCurrentQuarter
                .minusMonths(1) // Go back one month to reach the previous quarter
                .with(TemporalAdjusters.lastDayOfMonth());

        System.out.println("Last day of the previous quarter: " + lastDayOfPreviousQuarter);
        return lastDayOfPreviousQuarter;
    }

    public static String getFileExtension(String fileName) {
        if (fileName == null) {
            return null;
        }
        int dotIndex = fileName.lastIndexOf('.');
        if (dotIndex >= 0) {
            return fileName.substring(dotIndex + 1);
        } else {
            return ""; // No extension found
        }
    }
    @Data
    static class DateRangeDto {
        private String from;
        private String to;
    }
}
