package ibnk.tools.Interceptors;

import java.io.IOException;
import java.lang.reflect.Method;
import java.time.LocalDateTime;
import java.util.List;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import ibnk.dto.BankingDto.ClientQuestDto;
import ibnk.dto.auth.CustomerVerification;
import ibnk.models.ClientVerification;
import ibnk.models.InstitutionConfig;
import ibnk.models.client.Subscriptions;
import ibnk.models.enums.Status;
import ibnk.models.enums.VerificationType;
import ibnk.repository.ClientVerificationRepository;
import ibnk.service.CustomerService;
import ibnk.service.InstitutionConfigService;
import ibnk.tools.error.FailedSecurityVerification;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.web.method.HandlerMethod;
import org.springframework.web.servlet.HandlerInterceptor;
import reactor.util.annotation.NonNull;


@Component
public class SecurityQuestionInterceptor implements HandlerInterceptor {

    private final CustomerService customerService;
    private final ClientVerificationRepository clientVerificationRepository;
    private final InstitutionConfigService institutionConfigService;

    @Autowired
    public SecurityQuestionInterceptor(CustomerService customerService, ClientVerificationRepository clientVerificationRepository, InstitutionConfigService institutionConfigService) {
        this.customerService = customerService;
        this.clientVerificationRepository = clientVerificationRepository;
        this.institutionConfigService = institutionConfigService;
    }

    @Override
    public boolean preHandle(@NonNull  HttpServletRequest request,@NonNull HttpServletResponse response, @NonNull Object handler) throws Exception {
        if (handler instanceof HandlerMethod handlerMethod) {
            Method method = handlerMethod.getMethod();
            if (method.isAnnotationPresent(InterceptQuestions.class)) {
                Subscriptions subscription = (Subscriptions) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
                try {
                    String securityQuestionsJson = request.getHeader("X-User-Security");
                    if (securityQuestionsJson == null) {
                        throw new FailedSecurityVerification("Security questions are incorrect", null);
                    }

                    List<ClientQuestDto> securityQuestionsDTO = transformJsonToDTO(securityQuestionsJson);

                    if (securityQuestionsDTO == null) {
                        throw new FailedSecurityVerification("Security questions list are incorrect", null);
                    }
                    try {
                        institutionConfigService.verifySecurityQuestions(securityQuestionsDTO, subscription);
                    } catch (Exception e) {
                        throw new FailedSecurityVerification(e.getMessage(), null);
                    }
                } catch (Exception ex) {
                    ClientVerification verify = ClientVerification.builder()
                            .subscriptions(subscription)
                            .status(Status.FAILED)
                            .verified(false)
                            .verificationType(VerificationType.SECURITY_QUESTION)
                            .message(ex.getMessage())
                            .build();
                    clientVerificationRepository.save(verify);

                    CustomerVerification verificationObject = institutionConfigService.countRemainingCustomerTrials(subscription);

                    throw new FailedSecurityVerification(ex.getMessage(),verificationObject);
                }
            }
            return true;
        }
        return true;
    }

//    @Override
//    public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler, ModelAndView modelAndView) throws Exception {
//        // This method is called after the handler method is invoked, but before the view is rendered.
//        // You can perform post-processing logic here.
//    }

//    @Override
//    public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex) throws Exception {
//        // This method is called after the complete request has finished and the view has been rendered.
//        // You can perform cleanup logic here.
//    }

    private List<ClientQuestDto> transformJsonToDTO(String json) throws IOException {
        ObjectMapper mapper = new ObjectMapper();
        return mapper.readValue(json, new TypeReference<List<ClientQuestDto>>() {});
    }


}
