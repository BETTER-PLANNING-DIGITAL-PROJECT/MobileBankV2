package ibnk.tools.jwtConfig;

import ibnk.models.UserEntity;
import ibnk.models.client.Subscriptions;
import ibnk.tools.error.ResourceNotFoundException;
import ibnk.tools.error.UnauthorizedUserException;
import ibnk.tools.security.SecuritySubscriptionService;
import ibnk.tools.security.SecurityUserService;
import io.jsonwebtoken.ExpiredJwtException;
import jakarta.servlet.FilterChain;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.validation.constraints.NotNull;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;
import lombok.SneakyThrows;
import org.apache.http.HttpStatus;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import java.util.Optional;


@Component
@RequiredArgsConstructor
public class JwtTokenFilter  extends OncePerRequestFilter  {
    private final JwtService jwtService;
    private final SecurityUserService userService;
    private final SecuritySubscriptionService subscriptionService;

    @SneakyThrows
    @Override
    protected void doFilterInternal(
             HttpServletRequest request,
            @NonNull HttpServletResponse response,
            @NonNull FilterChain filterChain)  {

        try {
            String authHeader = request.getHeader("Authorization");

            String jwt;

            if(authHeader == null || !authHeader.startsWith("Bearer ")) {
                jwt = extractTokenFromQueryParameter(request);
            } else {
                jwt = authHeader.substring(7);
            }

            if (jwt == null || jwt.isEmpty()) {
                filterChain.doFilter(request, response);
                return;
            }

            String tokenType = jwtService.getTokenType(jwt);


            if ("User".equals(tokenType)) {
                    String userID = jwtService.extractUserID(jwt);
                    if (userID == null ) throw new UnauthorizedUserException("unauthorized_credentials");
                    UserEntity userDetails = userService.loadUserByUuid(userID);
                    if (!jwtService.isTokenValid(jwt, userDetails)) throw new UnauthorizedUserException("unauthorized_credentials");
                    authenticateUser(userDetails, request);
            }
            else if ("Client".equals(tokenType)) {
                String clientID = jwtService.extractClientID(jwt);
                if (clientID == null ) throw new UnauthorizedUserException("unauthorized_credentials");
                Optional<Subscriptions> userDetails = subscriptionService.loadClientByUuid(clientID);
                if(userDetails.isEmpty()) throw new UnauthorizedUserException("unauthorized_credentials");
                if (!jwtService.isTokenValidForClient(jwt, userDetails.get()))  throw new UnauthorizedUserException("unauthorized_credentials");
                authenticateUser(userDetails.get(), request);
            }
            filterChain.doFilter(request, response);
        } catch (Exception ex) {
            response.sendError(HttpServletResponse.SC_UNAUTHORIZED, ex.getMessage());
        }

    }

    private void authenticateUser(UserDetails userDetails, HttpServletRequest request) {
        UsernamePasswordAuthenticationToken authenticationToken = new UsernamePasswordAuthenticationToken(
                userDetails, null, userDetails.getAuthorities());
        authenticationToken.setDetails(new WebAuthenticationDetailsSource().buildDetails(request));
        SecurityContextHolder.getContext().setAuthentication(authenticationToken);
    }

    private String extractTokenFromQueryParameter(HttpServletRequest request) {
        return request.getParameter("token");
    }

}
