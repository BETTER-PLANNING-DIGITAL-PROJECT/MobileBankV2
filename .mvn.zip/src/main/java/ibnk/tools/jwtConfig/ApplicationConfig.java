package ibnk.tools.jwtConfig;

import ibnk.models.InstitutionConfig;
import ibnk.service.CustomerService;
import ibnk.service.InstitutionConfigService;
import ibnk.tools.Interceptors.SecurityQuestionInterceptor;
import ibnk.tools.error.ResourceNotFoundException;
import ibnk.tools.security.CustomAuthenticationProvider;
import ibnk.tools.security.SecuritySubscriptionService;
import ibnk.tools.security.SecurityUserService;
import jakarta.persistence.EntityManagerFactory;
import lombok.RequiredArgsConstructor;
import org.springframework.context.MessageSource;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.context.support.ReloadableResourceBundleMessageSource;
import org.springframework.http.HttpHeaders;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.ProviderManager;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.encrypt.BytesEncryptor;
import org.springframework.security.crypto.encrypt.Encryptors;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;
import org.springframework.web.filter.CorsFilter;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import java.util.*;


@Configuration
@EnableTransactionManagement
@EnableMethodSecurity(securedEnabled = true,jsr250Enabled = true)
@RequiredArgsConstructor
@EnableWebSecurity
public class ApplicationConfig {
    private final SecurityUserService userService;

    private final SecuritySubscriptionService clientService;


//    private UserDetailsService userDetailsService;

    private final EntityManagerFactory entityManagerFactory;


    @Bean
    public PlatformTransactionManager transactionManager() {
        JpaTransactionManager transactionManager = new JpaTransactionManager();
        transactionManager.setEntityManagerFactory(entityManagerFactory);
        return transactionManager;
    }

    @Bean
    public MessageSource messageSource() {
        ReloadableResourceBundleMessageSource messageSource
                = new ReloadableResourceBundleMessageSource();
        messageSource.setBasenames(
                "classpath:/messages/api_error_messages"
//                "classpath:/messages/api_response_messages"
        );
        messageSource.setDefaultEncoding("UTF-8");
        return messageSource;
    }

    @Bean
    @Primary
    public SecurityUserService userDetailsService() {
        System.out.println("Enter UserDetailService Bean");
        return userService;
    }



    @Bean
    public AuthenticationProvider authenticationProvider(){
        return  new CustomAuthenticationProvider(userDetailsService(),passwordEncoder());
    }
    @Bean
    @Primary
    public SecuritySubscriptionService clientDetailsService() {
        System.out.println("Enter ClientDetailService Bean");
        return clientService;
    }

    @Bean
    public AuthenticationProvider authenticationProviderClient(){
        return  new CustomAuthenticationProvider.CustomAuthenticationClientProvider(clientDetailsService(),passwordEncoder());
    }

    @Bean
    public AuthenticationManager authenticationManager() {
        List<AuthenticationProvider> providers = Arrays.asList(authenticationProviderClient(),authenticationProvider());
        return new ProviderManager(providers);
    }
    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    @Bean
    public CorsFilter corsFilter() {
        final UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
        final CorsConfiguration config = new CorsConfiguration();
        config.setAllowedOrigins(Collections.singletonList("*"));
        config.setAllowedHeaders(Arrays.asList(
                HttpHeaders.ORIGIN,
                HttpHeaders.ACCEPT,
                HttpHeaders.CONTENT_TYPE,
                HttpHeaders.AUTHORIZATION,
                "X-User-Security"
        ));
        config.setAllowedMethods(Arrays.asList(
                "GET",
                "POST",
                "DELETE",
                "PUT",
                "PATCH"
        ));
        source.registerCorsConfiguration("/**", config);
        return new CorsFilter(source);
    }



    @Configuration
    @RequiredArgsConstructor
    public  class ApiTokenSecurityConfigurationAdapter {
        private final JwtTokenFilter jwtAuthFilter;
        @Bean
        public UserDetailsService userDetailsService_User1() {
            return new SecurityUserService();
        }

        private final AuthenticationProvider authenticationProvider = new CustomAuthenticationProvider(userService, new BCryptPasswordEncoder());

        @Bean
        public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
            http
                    .securityMatcher("/api/v1/admin/**")
                    .authenticationProvider(authenticationProvider)
                    .addFilterBefore(jwtAuthFilter, UsernamePasswordAuthenticationFilter.class)
                    .cors()
                    .and()
                    .csrf()
                    .disable()
                    .authorizeHttpRequests()
                    .requestMatchers("/api/v1/otp/**", "/api/v1/admin/auth/**", "http://localhost:8888/w1", "/v3/api-docs", "/v3/api-docs/swagger-config", "/swagger-resources", "/swagger-resources/**", "/configuration/ui", "/configuration/security", "/webjars/**", "/swagger-ui/**", "/swagger-ui.html")
                    .permitAll()
                    .anyRequest()
                    .authenticated()
                    .and()
                    .userDetailsService(new SecurityUserService())
                    .sessionManagement()
                    .sessionCreationPolicy(SessionCreationPolicy.STATELESS)
                    .and()
                    .exceptionHandling();
            http.httpBasic();
            return http.build();
        }

    }


    @Configuration
    @RequiredArgsConstructor
    public  class ClientTokenSecurityConfigurationAdapter {
        private final  JwtTokenFilter jwtAuthFilter;
        @Bean
        public UserDetailsService userDetailsService_User2() {
            return new SecuritySubscriptionService();
        }

        private final AuthenticationProvider authenticationProvider = new CustomAuthenticationProvider.CustomAuthenticationClientProvider(clientService, new BCryptPasswordEncoder());

        @Bean
        public SecurityFilterChain securityClientFilterChain(HttpSecurity http) throws Exception {
            http
                    .securityMatcher("/api/v1/client/**")
                    .authenticationProvider(authenticationProvider)
                    .addFilterBefore(jwtAuthFilter, UsernamePasswordAuthenticationFilter.class)
                    .cors()
                    .and()
                    .csrf()
                    .disable()
                    .authorizeHttpRequests()
                    .requestMatchers("/api/v1/otp/**", "/api/v1/client/auth/**", "http://localhost:8888/w1", "/v3/api-docs", "/v3/api-docs/swagger-config", "/swagger-resources", "/swagger-resources/**", "/configuration/ui", "/configuration/security", "/webjars/**", "/swagger-ui/**", "/swagger-ui.html")
                    .permitAll()
                    .anyRequest()
                    .authenticated()
                    .and()
                    .userDetailsService(new SecuritySubscriptionService())
                    .sessionManagement()
                    .sessionCreationPolicy(SessionCreationPolicy.STATELESS)
                    .and()
                    .exceptionHandling();
            http.httpBasic();
            return http.build();
        }

    }



}
