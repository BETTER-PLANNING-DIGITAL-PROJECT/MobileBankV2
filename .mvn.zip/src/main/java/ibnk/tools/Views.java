package ibnk.tools;

public class Views {
    public static class MenuView {}
    public static class ModuleView {}
    public static class RoleView extends ModuleView {}
    public static class EnterpriseView extends ModuleView {}
    public static class UserView extends RoleView {}
}
