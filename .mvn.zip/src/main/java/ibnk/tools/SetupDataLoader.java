package ibnk.tools;

import ibnk.models.InstitutionConfig;
import ibnk.models.NotificationTemplate;
import ibnk.models.UserEntity;
import ibnk.models.enums.EventCode;
import ibnk.models.enums.OtpChanel;
import ibnk.models.enums.QuestionEnum;
import ibnk.repository.NotificationTemplateRepository;
import ibnk.repository.RolesRepo;
import ibnk.repository.UserRepository;
import ibnk.service.InstitutionConfigService;
import jakarta.transaction.Transactional;
import org.springframework.context.ApplicationListener;
import org.springframework.context.event.ContextRefreshedEvent;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import java.util.Optional;


@Component
public class SetupDataLoader implements
        ApplicationListener<ContextRefreshedEvent> {
    boolean alreadySetup = false;
    private final UserRepository userRepository;
    private final InstitutionConfigService institutionConfigService;
    private final PasswordEncoder passwordEncoder;

    private final NotificationTemplateRepository notificationTemplateRepository;
    private final RolesRepo rolesRepo;

    public SetupDataLoader(UserRepository userRepository, PasswordEncoder passwordEncoder, InstitutionConfigService institutionConfigService, NotificationTemplateRepository notificationTemplateRepository, RolesRepo rolesRepo) {
        this.userRepository = userRepository;
        this.institutionConfigService = institutionConfigService;
        this.passwordEncoder = passwordEncoder;
        this.notificationTemplateRepository = notificationTemplateRepository;
        this.rolesRepo = rolesRepo;
    }

    @Override
    @Transactional
    public void onApplicationEvent(ContextRefreshedEvent event) {
        if (alreadySetup) return;
        UserEntity user = UserEntity.builder()
                .id(1L)
                .uuid("5dde1e2b-3543-47b3-a48e-d4e512b5d056")
                .name("Test")
                .passExpiration(false)
                .doubleAuthentication(false)
                .role(rolesRepo.findById(1L).get())
                .firstLogin(false)
                .password(passwordEncoder.encode("11112222"))
                .userLogin("20000")
                .build();
        userRepository.save(user);

        InstitutionConfig institutionConfig = InstitutionConfig.builder()
                .id(1L)
                .institutionName("BETTER PLANNING LTD")
                .institutionEmail("philfontah911@gmail.com")
                .emailPassword("uekn cbzg jntw bnal")
                .host("smtp.gmail.com")
                .emailNoReply("benzeezmokom@gmail.com")
                .port(587L)
                .questConfig(QuestionEnum.AUTO)
                .maxSecurityQuest(2L)
                .minSecurityQuest(2L)
                .verifyQuestNumber(1)
                .verificationResetTimer(15)
                .maxVerifyAttempt(6L)
                .build();
        institutionConfigService.saveInstitutionConfig(institutionConfig);

        insertEnumValues();

        alreadySetup = true;
    }

    public void insertEnumValues() {
        for (EventCode eventCode : EventCode.values()) {
            Optional<NotificationTemplate> smsEvent = notificationTemplateRepository.findByNotificationTypeAndEventCode(OtpChanel.SMS, String.valueOf(eventCode));
            if(smsEvent.isEmpty()) {
                NotificationTemplate  newSmsEvent =  NotificationTemplate.builder()
                        .eventCode(String.valueOf(eventCode))
                        .status("INACTIVE")
                        .template("")
                        .notificationType(OtpChanel.SMS).build();
                notificationTemplateRepository.save(newSmsEvent);
            }
            Optional<NotificationTemplate> mailEvent = notificationTemplateRepository.findByNotificationTypeAndEventCode(OtpChanel.MAIL, String.valueOf(eventCode));
            if(mailEvent.isEmpty()) {
                NotificationTemplate  newSmsEvent =  NotificationTemplate.builder()
                        .eventCode(String.valueOf(eventCode))
                        .status("INACTIVE")
                        .template("")
                        .notificationType(OtpChanel.MAIL).build();
                notificationTemplateRepository.save(newSmsEvent);
            }
        }
    }
}
