package ibnk.tools.security;

import ibnk.dto.UserDto;
import ibnk.models.UserEntity;
import ibnk.repository.BankingRepository;
import ibnk.repository.UserRepository;
import ibnk.service.UserService;
import ibnk.tools.error.FailedLoginException;
import ibnk.tools.error.ResourceNotFoundException;
import ibnk.tools.error.UnauthorizedUserException;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
//import org.hibernate.Hibernate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

@Service()
@Transactional

public class SecurityUserService implements UserDetailsService {

        @Autowired
        private  UserRepository userRepository;

        @Autowired
        private BankingRepository bankingRepository;
        private final Logger LOGGER = LogManager.getLogger(SecurityUserService.class);

        @Override
        public UserEntity loadUserByUsername(String userLogin) throws UsernameNotFoundException   {
            LOGGER.info("Enter >> loadUserByUsername");
            UserEntity user = userRepository.findByUserLogin(userLogin).orElseThrow(() -> new UsernameNotFoundException("failed_login"));
            LOGGER.info("Exit >> loadUserByUsername");
            return user;
        }

        public UserEntity loadUserByUuid(String uuid) throws UnauthorizedUserException, SQLException, ResourceNotFoundException {
            LOGGER.info("Enter >> loadUserByUuid");
            Optional<UserEntity> user = userRepository.findUserByUuid(uuid);
            if(user.isEmpty()) {
                throw new UnauthorizedUserException("Unauthorized");
            }
            UserEntity userDetails =  user.get();
            UserDto.EmployeeDto employee = findEmployeeById(userDetails.getUserLogin());
            if(employee.isSuspension()) {
                throw new UnauthorizedUserException("Unauthorized");
            }
            LOGGER.info("Exit >> loadUserByUuid");
            return userDetails;

        }

    public UserDto.EmployeeDto findEmployeeById (String employeeId) throws SQLException, ResourceNotFoundException {
        Connection connection = bankingRepository.getConnection();
        String sql = "SELECT Agence\n" +
                ",Matricule\n" +
                ",NomPrenom\n" +
                ",LibQualite\n" +
                ",Suspension\n" +
                ",Status\n" +
                "FROM [dbo].[Employe]\n" +
                "WHERE Matricule = ?";
        PreparedStatement preparedStatement = connection.prepareStatement(sql);
        preparedStatement.setString(1, employeeId);
        ResultSet resultSet = preparedStatement.executeQuery();
        List<UserDto.EmployeeDto> result = new ArrayList<>();
        while (resultSet.next()) {
            result.add(UserDto.EmployeeDto.DtoToModel(resultSet));
        }
        return result.stream()
                .findFirst()
                .orElseThrow(() -> new ResourceNotFoundException("employee_not_found"));

    }
    }
