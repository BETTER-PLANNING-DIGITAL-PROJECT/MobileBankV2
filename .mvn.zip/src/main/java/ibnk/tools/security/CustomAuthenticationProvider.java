package ibnk.tools.security;

import ibnk.models.UserEntity;
import ibnk.models.client.Subscriptions;
import ibnk.tools.error.FailedLoginException;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import java.sql.SQLException;

@Component
public class CustomAuthenticationProvider implements AuthenticationProvider {
    private final SecurityUserService userDetailsService;
    private final PasswordEncoder passwordEncoder;

    public CustomAuthenticationProvider(SecurityUserService userDetailsService, PasswordEncoder passwordEncoder) {
        this.userDetailsService = userDetailsService;
        this.passwordEncoder = passwordEncoder;
    }


    @Override
    public Authentication authenticate(Authentication authentication) throws AuthenticationException {
        String username = authentication.getName();
        String password = authentication.getCredentials().toString();

        UserEntity user = this.userDetailsService.loadUserByUsername(username);

        String userUuid = null;
        String loginType = null;

        if(user != null) {
            userUuid = user.getUuid();
            loginType = "ADMIN";
        }
//        else if(client != null) {
//            userUuid = client.getUuid();
//            loginType = "CLIENT";
//        }

        if (!this.passwordEncoder.matches(password, user.getPassword())) {
            throw new FailedLoginException("failed_login",userUuid, "FAILED_PASSWORD", loginType);
        }

        return new UsernamePasswordAuthenticationToken(user, password, user.getAuthorities());
    }

    @Override
    public boolean supports(Class<?> authentication) {
        return authentication.equals(UsernamePasswordAuthenticationToken.class);
    }

    @Component
    public static class CustomAuthenticationClientProvider implements AuthenticationProvider {
        private final SecuritySubscriptionService securitySubscriptionService;
        private final PasswordEncoder passwordEncoder;

        public CustomAuthenticationClientProvider(SecuritySubscriptionService securitySubscriptionService, PasswordEncoder passwordEncoder) {
            this.securitySubscriptionService = securitySubscriptionService;
            this.passwordEncoder = passwordEncoder;
        }


        @Override
        public Authentication authenticate(Authentication authentication) throws AuthenticationException {
            String username = authentication.getName();
            String password = authentication.getCredentials().toString();

            Subscriptions client = this.securitySubscriptionService.loadUserByUsername(username);

            String userUuid = null;
            String loginType = null;


        if(client != null) {
            userUuid = client.getUuid();
            loginType = "CLIENT";
        }

            if (!this.passwordEncoder.matches(password, client.getPassword())) {
                throw new FailedLoginException("failed_login",userUuid, "FAILED_PASSWORD", loginType);
            }

            return new UsernamePasswordAuthenticationToken(client, password, client.getAuthorities());
        }

        @Override
        public boolean supports(Class<?> authentication) {
            return authentication.equals(UsernamePasswordAuthenticationToken.class);
        }
    }
}
