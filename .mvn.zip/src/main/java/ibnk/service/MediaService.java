package ibnk.service;

import ibnk.models.Media;
import ibnk.repository.MediaRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.Optional;
@RequiredArgsConstructor
@Service
public class MediaService {
    private final MediaRepository mediaRepository;

    public Media save(Media media) {
        return mediaRepository.save(media);
    }

//    public Optional<Media> findForUserByUuidOrFail(UserEntity user, String uuid) {
//        return mediaRepository.findByOwnerAndUuid(user, uuid);
//    }

//    public Media listmediaById(Long mediaId){
//        mediaRepository.findById(mediaId);
//    }

    public Optional<Media> findByUuid(String uuid) {
        return mediaRepository.findByUuid(uuid);
    }

    public Optional<Media> findImageByUuid(Long id) {
        return mediaRepository.findById(id)
                .map(media -> {
                    // You can perform additional operations here if needed
                    return media;
                });
    }
}
