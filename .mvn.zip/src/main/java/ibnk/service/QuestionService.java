package ibnk.service;

import ibnk.models.InstitutionConfig;
import ibnk.models.client.SecurityQuestions;
import ibnk.repository.ClientSecurityQuestionRepository;
import ibnk.repository.InstitutionConfigRepository;
import ibnk.repository.SecurityQuestionRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@RequiredArgsConstructor
@Service
public class QuestionService {
    private final SecurityQuestionRepository securityQuestionRepository;
    private final ClientSecurityQuestionRepository clientSecurityQuestionRepository;
    private final InstitutionConfigRepository institutionConfigRepository;

    public String saveSecurityQuestions(SecurityQuestions quests) {
        securityQuestionRepository.save(quests);
        return "Success";
    }

    public String deleteSecurityQuestion(Long id) {
        securityQuestionRepository.deleteById(id);
        return "Deleted";
    }

    public List<SecurityQuestions> listAllQuestions() {
        return securityQuestionRepository.findAll();
    }
    public List<SecurityQuestions> listQuestionsByClientId(Long ClientId){
        return clientSecurityQuestionRepository.listClientSecurityQuestions(ClientId);
    }


}
