package ibnk.service;

import ibnk.dto.auth.OtpAuth;
import ibnk.dto.auth.CustomerVerification;
import ibnk.models.ClientVerification;
import ibnk.models.NotificationTemplate;
import ibnk.models.OtpEntity;
import ibnk.models.client.Subscriptions;
import ibnk.models.enums.OtpChanel;
import ibnk.models.enums.OtpEnum;
import ibnk.models.enums.Status;
import ibnk.models.enums.VerificationType;
import ibnk.repository.ClientVerificationRepository;
import ibnk.repository.NotificationTemplateRepository;
import ibnk.repository.OtpRepository;
import ibnk.tools.error.ExpiredPasswordException;
import ibnk.tools.error.FailedSecurityVerification;
import ibnk.tools.error.ResourceNotFoundException;
import ibnk.tools.nexaConfig.EmailService;
import ibnk.tools.nexaConfig.NexaResponse;
import ibnk.tools.nexaConfig.NexaService;
import ibnk.tools.security.PasswordConstraintValidator;
import lombok.RequiredArgsConstructor;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import java.lang.reflect.Field;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.Random;
import java.util.concurrent.CompletableFuture;


@Service()
@RequiredArgsConstructor
public class OtpService {
    private final OtpRepository otpRepository;
    private final NexaService nexaService;

    private final EmailService emailService;
    private final NotificationTemplateRepository notificationTemplateRepository;

    private final InstitutionConfigService institutionConfigService;

    private final ClientVerificationRepository clientVerificationRepository;
    public static int GenerateOtp() {
        Random random = new Random();
        return ((1 + random.nextInt(2)) * 10000 + random.nextInt(10000));
    }

    @Async()
    public CompletableFuture SendOtp(OtpEntity otp, List<Object> payloads)  {
        String OtpMessage;
        String OtpSubject = "";
        Optional<NotificationTemplate> notificationTemplate = notificationTemplateRepository.findByNotificationTypeAndEventCode(otp.getTransport(), String.valueOf(otp.getRole()));

        if (notificationTemplate.isPresent()) {
            if (notificationTemplate.get().getStatus().equals("ACTIVE")) {
                payloads.add(otp);
                OtpMessage = replaceParameters(notificationTemplate.get().getTemplate(),payloads);
                OtpSubject = replaceParameters(notificationTemplate.get().getSubject(),payloads);
            } else {
                OtpMessage = OtpMessageTemplate(otp);
            }
        }
        else {
            OtpMessage = OtpMessageTemplate(otp);
        }

        if(otp.getTransport().equals(OtpChanel.SMS) ) {
            var next = NexaResponse.builder().sms(OtpMessage).mobiles(otp.getDestination()).senderid("GBLOAN").build();
            nexaService.LessSms(next);
        } else if (otp.getTransport().equals(OtpChanel.MAIL)) {
            emailService.sendSimpleMessage(otp.getDestination(), OtpSubject, OtpMessage);
        }
        return CompletableFuture.completedFuture(null);
    }

//    public OtpEntity ResendOtp(String uuid) throws ResourceNotFoundException {
//        Optional<OtpEntity> result = otpRepository.findByUuid(uuid);
//        if (result.isEmpty()) {
//            throw new ResourceNotFoundException("FAILED_TO_SEND_OTP");
//        }
//        OtpEntity otp = result.get();
//        if (otp.getUsed()) {
//            throw new ResourceNotFoundException("FAILED_TO_SEND_OTP");
//        }
//        return GenerateAndSend(otp, null);
//    }


    public CustomerVerification GenerateAndSend(OtpEntity params, List<Object> payloads, Subscriptions subscriptions) throws  ResourceNotFoundException {
        otpRepository.deleteByRoleAndDestinationAndGuid(params.getRole(), params.getDestination(), params.getGuid());
        Long otpCode = (long) GenerateOtp();
        if(params.getTransport().equals(OtpChanel.SMS)){

            if(!PasswordConstraintValidator.isValidCameroonPhoneNumber(params.getDestination())){
                throw new ResourceNotFoundException("Invalid PhoneNumber");
            }
            if(!PasswordConstraintValidator.isValidEmail(params.getDestination())){
                throw new ResourceNotFoundException("Invalid Email Address");
            }
        }

        OtpEntity otp = OtpEntity.builder()
                .otp(otpCode)
                .role(params.getRole())
                .expiresAt(LocalDateTime.now().plusMinutes(15))
                .minBeforeExpire(3L)
                .transport(params.getTransport())
                .destination(params.getDestination())
                .sent(false)
                .used(false)
                .guid(params.getGuid())
                .build();

        CustomerVerification verification = institutionConfigService.countRemainingCustomerTrials(subscriptions);

        OtpEntity res = otpRepository.save(otp);
        verification.setVerificationObject(res);
        verification.setVerificationType("OTP");
        CompletableFuture.runAsync(() -> SendOtp(res, payloads));
        return verification;

    }


    static String OtpMessageTemplate(OtpEntity otp) {
        String otpMessage = "";
        switch (otp.getRole()) {
            case LOGIN -> otpMessage = "Your Authentication OTP is : " + otp.getOtp();
            case RESET_PASSWORD -> otpMessage = "Your ResetPassword OTP is :" + otp.getOtp();
        }
        return otpMessage;
    }

    public void verifyOtpOnGenerate(OtpEnum role, String guid) {
        var res = otpRepository.findByRoleAndGuid(role, guid);
        if (res.isPresent()) {
            System.out.println(res);
            if (res.get().getGuid().equals(guid) && res.get().getRole().equals(role)) {
                otpRepository.deleteById(res.get().getId());
            }
        }
    }

    public Boolean VerifyOtp(OtpAuth otp, String guid, Subscriptions sub) throws ResourceNotFoundException {
        try {
            Optional<OtpEntity> OtpSms = otpRepository.findByRoleAndGuidAndUsed(OtpEnum.valueOf(otp.getRole()), guid, false);
            if (OtpSms.isEmpty()) {
                throw new ResourceNotFoundException("Not found");
            }
            if (OtpSms.get().getExpiresAt().isBefore(LocalDateTime.now()))
                throw new ExpiredPasswordException("Your_Otp_expired");

            if (OtpSms.get().getOtp() != otp.getOtp()) {
                throw new ResourceNotFoundException("Otp Does Not Match");
            }
            OtpSms.get().setUsed(true);
            otpRepository.save(OtpSms.get());
            institutionConfigService.archiveClientVerifications(sub);
            return true;
        } catch (Exception ex) {
            ClientVerification verify = ClientVerification.builder()
                    .subscriptions(sub)
                    .status(Status.FAILED)
                    .verified(false)
                    .verificationType(VerificationType.SECURITY_QUESTION)
                    .message(ex.getMessage())
                    .build();
            clientVerificationRepository.save(verify);
            CustomerVerification verificationObject = institutionConfigService.countRemainingCustomerTrials(sub);
            throw new FailedSecurityVerification(ex.getMessage(),verificationObject);
        }
    }

    public static String replaceParameters(String template, List<Object> payloads) {
        if(payloads.isEmpty()){
            return template;
        }
        for (Object payload: payloads) {
            // Get the class of the User object
            Class<?> clazz = payload.getClass();

            // Iterate over declared fields in the class
            for (Field field : clazz.getDeclaredFields()) {
                // Get the field name
                String fieldName = field.getName();
                // Get the field value using reflection
                try {
                    field.setAccessible(true); // Allow accessing private fields
                    Object value = field.get(payload); // Get the value of the field
                    if(value != null) {
                        template = template.replace("%" + fieldName + "%", value.toString());
                    }
                } catch (IllegalAccessException ignored) {
                    System.out.println("111111111111111111111111 theres an error with field name   " + fieldName);
                }
            }
        }

        return template;
    }
}
