package ibnk.service;

import ibnk.dto.BankingDto.ClientQuestDto;
import ibnk.dto.auth.CustomerVerification;
import ibnk.models.ClientVerification;
import ibnk.models.ClientVerificationArchive;
import ibnk.models.InstitutionConfig;
import ibnk.models.NotificationTemplate;
import ibnk.models.client.ClientSecurityQuestion;
import ibnk.models.client.Subscriptions;
import ibnk.models.enums.OtpChanel;
import ibnk.models.enums.Status;
import ibnk.models.enums.VerificationType;
import ibnk.repository.*;
import ibnk.tools.error.FailedSecurityVerification;
import ibnk.tools.error.ResourceNotFoundException;
import lombok.RequiredArgsConstructor;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@RequiredArgsConstructor
@Service
public class InstitutionConfigService {

    private final InstitutionConfigRepository institutionConfigRepository;
    private final NotificationTemplateRepository notificationTemplateRepository;
    private final PasswordEncoder passwordEncoder;


    private final ClientSecurityQuestionRepository clientSecurityQuestionRepository;
    private final ClientVerificationRepository clientVerificationRepository;
    private final ClientVerificationArchiveRepository clientVerificationArchiveRepository;
    public void saveInstitutionConfig(InstitutionConfig institutionConfig) {
        institutionConfigRepository.save(institutionConfig);
    }

    public String updateInstitutionConfig(InstitutionConfig institutionConfig) throws ResourceNotFoundException {
        InstitutionConfig institutionConfig1 = institutionConfigRepository.findById(institutionConfig.getId())
                .orElseThrow(() -> new ResourceNotFoundException("Config Does not Exist"));
         institutionConfig1.setQuestConfig(institutionConfig.getQuestConfig());
         institutionConfig1.setMaxSecurityQuest(institutionConfig.getMaxSecurityQuest());
         institutionConfig1.setMinSecurityQuest(institutionConfig.getMinSecurityQuest());
         institutionConfig1.setVerifyQuestNumber(institutionConfig.getVerifyQuestNumber());
         institutionConfig1.setInstitutionName(institutionConfig.getInstitutionName());
         institutionConfig1.setMaxVerifyAttempt(institutionConfig.getMaxVerifyAttempt());
         institutionConfig1.setInstitutionEmail(institutionConfig.getInstitutionEmail());
         institutionConfig1.setEmailPassword(passwordEncoder.encode(institutionConfig.getEmailPassword()));

         institutionConfigRepository.save(institutionConfig1);
        return "Updated";
    }

    public InstitutionConfig listConfig() throws ResourceNotFoundException {
      return institutionConfigRepository.findAll().stream().findFirst()
              .orElseThrow(()->new ResourceNotFoundException("Empty"));

    }


    public NotificationTemplate findById(Long id) throws ResourceNotFoundException {
        return notificationTemplateRepository.findById(id).orElseThrow(() -> new ResourceNotFoundException("Not Found"));
    }

    public String UpdateNotifTemplate(Long id, NotificationTemplate dto) throws ResourceNotFoundException {
        NotificationTemplate notificationTemplate = findById(id);
        notificationTemplate.setTemplate(dto.getTemplate());
        notificationTemplate.setSubject(dto.getSubject());
        notificationTemplateRepository.save(notificationTemplate);
        return "Success";
    }

    public NotificationTemplate findByNotificationTypeAndEventCode(String notification,String eventCode) throws ResourceNotFoundException {
        return    notificationTemplateRepository.findByNotificationTypeAndEventCode(OtpChanel.valueOf(notification),eventCode)
                .orElseThrow(()->new ResourceNotFoundException("Not Exist"));
    }

    public String deleteNotifById(Long id) throws ResourceNotFoundException {
        NotificationTemplate del = findById(id);
        notificationTemplateRepository.deleteById(id);
        return "Deleted successfully: " + del;
    }
    public List<NotificationTemplate> listNotifTemplate() {
        return notificationTemplateRepository.findAll();
    }


    public CustomerVerification countRemainingCustomerTrials(Subscriptions sub) throws ResourceNotFoundException {
        InstitutionConfig config = listConfig();

        LocalDateTime time =  LocalDateTime.now().minusMinutes(config.getVerificationResetTimer());
        Integer previousTrials = clientVerificationRepository.countPreviousFailedTrials(sub, Status.FAILED, time);
        Integer leftTrials = Math.toIntExact(config.getMaxVerifyAttempt() - previousTrials);
        CustomerVerification responseData = new CustomerVerification();

        responseData.setTrials(leftTrials);
        responseData.setMaxTrials(Math.toIntExact(config.getMaxVerifyAttempt()));
        return responseData;
    }

    public void archiveClientVerifications(Subscriptions sub) {
        List<ClientVerification> verifications = clientVerificationRepository.findClientVerificationBySubscriptions(sub);
        List<ClientVerificationArchive> archives = new ArrayList<>();

        for (ClientVerification verification : verifications) {
            ClientVerificationArchive archive = new ClientVerificationArchive();

            archive.setId(verification.getId());
            archive.setUuid(verification.getUuid());
            archive.setRole(verification.getRole());
            archive.setVerificationType(verification.getVerificationType());
            archive.setVerified(verification.isVerified());
            archive.setSubscriptions(sub);
            archive.setMessage(verification.getMessage());
            archive.setStatus(verification.getStatus());

            archives.add(archive);
        }
        clientVerificationArchiveRepository.saveAll(archives);
        clientVerificationRepository.deleteAllInBatch(verifications);
    }

    public ClientVerification verifySecurityQuestions(List<ClientQuestDto> json, Subscriptions subs) throws ResourceNotFoundException {
        InstitutionConfig config = listConfig();
        if (config.getVerifyQuestNumber() != json.size()) {
            throw new FailedSecurityVerification("Insufficient Questions for this Process", null);
        }

        for (ClientQuestDto QuestDto : json) {
            Optional<ClientSecurityQuestion> clientQuestion = clientSecurityQuestionRepository.findByClientIdAndQuestionId(subs.getId(), QuestDto.getSecurityQuestionId());
            if (clientQuestion.isEmpty()) {
                throw new FailedSecurityVerification("question-not-set", null);
            }
            boolean answerMatch = passwordEncoder.matches(QuestDto.getSecurityAns(), clientQuestion.get().getSecurityAns());
            if (!answerMatch) {
                throw new FailedSecurityVerification("wrong-answer", null);
            }

        }
        ClientVerification verify = ClientVerification.builder()
                .subscriptions(subs)
                .status(Status.SUCCESS)
                .verified(true)
                .verificationType(VerificationType.SECURITY_QUESTION)
                .build();
        clientVerificationRepository.save(verify);
        archiveClientVerifications(subs);
        return verify;
    }


}
