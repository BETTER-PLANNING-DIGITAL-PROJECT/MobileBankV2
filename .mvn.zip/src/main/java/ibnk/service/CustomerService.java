package ibnk.service;

import ibnk.dto.BankingDto.AccountEntityDto;
import ibnk.dto.BankingDto.ClientQuestDto;
import ibnk.dto.EventObjectDto;
import ibnk.dto.SubscriptionDao;
import ibnk.dto.SubscriptionRequestDto;
import ibnk.dto.UserDto;
import ibnk.dto.auth.*;
import ibnk.models.*;
import ibnk.models.client.ClientSecurityQuestion;
import ibnk.models.client.Subscriptions;
import ibnk.models.enums.*;
import ibnk.repository.*;
import ibnk.service.BankingService.AccountService;
import ibnk.tools.TOOLS;
import ibnk.tools.error.ExpiredPasswordException;
import ibnk.tools.error.FailedSecurityVerification;
import ibnk.tools.error.ResourceNotFoundException;
import ibnk.tools.error.UnauthorizedUserException;
import ibnk.tools.jwtConfig.JwtService;
import ibnk.tools.response.AuthResponse;
import ibnk.tools.security.PasswordConstraintValidator;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import javax.management.BadAttributeValueExpException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.util.*;

@RequiredArgsConstructor
@Service
public class CustomerService {
    private final PasswordEncoder passwordEncoder;
    private final AuthenticationManager authenticationManager;
    private final OtpService otpService;
    private final JwtService jwtService;
    private final Logger LOGGER = LogManager.getLogger(AuthenticationService.class);
    private final SubscriptionRepository subscriptionRepository;
    private final AccountService accountService;
    private final BankingRepository bankingRepository;
    private final ClientSecurityQuestionRepository clientSecurityQuestionRepository;
    private final InstitutionConfigService institutionConfigService;
    private final ClientVerificationRepository clientVerificationRepository;

    public Subscriptions findClientByUuid(String uuid) throws ResourceNotFoundException {
        Optional<Subscriptions> sub = subscriptionRepository.findByUuid(uuid);
        if (sub.isEmpty()) {
            throw new ResourceNotFoundException("Subscriber does not Exist");
        }
        return sub.get();
    }

    private Boolean updateClientMobileTypeAndPrimaryAccount( SubscriptionDao dao, String clientId, String EbnkSub) throws SQLException {
        Connection connection = bankingRepository.getConnection();
        String sql = "UPDATE ClientBnk SET  MobileType = ? , Eaccount = ?, EbnkSub = ? WHERE client = ?";
        PreparedStatement preparedStatement = connection.prepareStatement(sql);
        preparedStatement.setString(1, dao.getPackageCode());
        preparedStatement.setString(2, dao.getAccountId());
        preparedStatement.setString(3, EbnkSub);
        preparedStatement.setString(4, clientId);
        int rowsAffected = preparedStatement.executeUpdate();
        if (rowsAffected > 1) {
            connection.rollback();
            connection.close();
            return false;
        } else {
            connection.commit();
            connection.close();
            return rowsAffected == 1;
        }
    }

    @Transactional
    public UserDto.CreateSubscriberClientDto Subscribe(SubscriptionDao dao, UserEntity subs) throws SQLException, ResourceNotFoundException {
        UserDto.CreateSubscriberClientDto dto = new UserDto.CreateSubscriberClientDto();
        List<AccountEntityDto> accountEntityDto = accountService.findClientAccounts(dao.getAccountId());
        AccountEntityDto accountInfo = accountEntityDto
                .stream()
                .findFirst()
                .orElseThrow(() -> new ResourceNotFoundException(dao.getAccountId() + " Does Not Exist Please Make Sure you have an Account"));


        Optional<Subscriptions> subscribed = subscriptionRepository.findByClientMatricul(accountInfo.getClientID());
        if(subscribed.isPresent()) throw new ResourceNotFoundException("customer_already_subscribed");

        subscribed = subscriptionRepository.findByUserLogin(dao.getUserLogin());
        if(subscribed.isPresent()) throw new ResourceNotFoundException("user_login_already_exist");

        if(accountInfo.getMobile() == null || accountInfo.getMobile().isEmpty()) {
            throw new ResourceNotFoundException("please_add_customer_phoneNumber");
        }

        subscribed = subscriptionRepository.findByPhoneNumber(accountInfo.getMobile());
        if(subscribed.isPresent()) throw new ResourceNotFoundException("user_phone_already_exist");

        if (Objects.equals(accountInfo.getMobileType(), null)) {
            accountService.findMbConfigByCode(dao.getPackageCode());
           boolean setPrimaryAccount =  updateClientMobileTypeAndPrimaryAccount(dao, accountInfo.getClientID(), "ST1");
           if(!setPrimaryAccount) throw new ResourceNotFoundException("client_not_found");


        } else {
            if (!Objects.equals(accountInfo.getEaccount(), dao.getAccountId())) {
                throw new ResourceNotFoundException("Mobile Bank Primary Account is different do you want to continue");
            }
        }

        Subscriptions subscription = ClientToSubscribe(dto, accountInfo, subs);
        subscription.setSubscriberBy(subs);
        subscription.setFirstLogin(false);
        subscription.setBranchCode(accountInfo.getOurBranchID());
        subscription.setUserLogin(dao.getUserLogin());
        String valid = validateInternetBankingSubscription(dao, subs, accountInfo.getClient());
        if(valid == null) {
            dao.setPackageCode(null);
            dao.setAccountId(null);
            updateClientMobileTypeAndPrimaryAccount(dao, accountInfo.getClientID(), null);
            throw new ResourceNotFoundException("account_not_found");
        };
        subscription.setPassword(passwordEncoder.encode(valid));
        subscription = subscriptionRepository.save(subscription);
        return UserDto.CreateSubscriberClientDto.modelToDao(subscription);
    }

    public String validateInternetBankingSubscription(SubscriptionDao dao, UserEntity user, String client) throws ResourceNotFoundException {
        SimpleJdbcCall call = new SimpleJdbcCall(bankingRepository.dataSource2()).withProcedureName("PS_VALIDATE_INTBANKING");
        MapSqlParameterSource in = new MapSqlParameterSource()
                .addValue("ws_client", client)
                .addValue("Type", 2)
                .addValue("takefee", dao.getApplyFee())
                .addValue("wEmploye", user.getUserLogin())
                .addValue("Language", "En")
                .addValue("Computername", "INTERNET BANKING")
                .addValue("pc_OutLECT", null)
                .addValue("pc_OutLECT", null)
                .addValue("Password", null);
        Map<String, Object> out = call.execute(in);
        if((Integer) out.get("pc_OutLECT") != 0) return null;

        return (String) out.get("Password");
    }
    public AuthResponse<Object, Object> authenticate(AuthDto request) throws UnauthorizedUserException {
        LOGGER.info("Enter >> Client Authentication Function");
        try {
            Authentication authentication = authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(request.getUserLogin(), request.getPassword()));
            Object client1 = authentication.getPrincipal();
            if (client1 instanceof UserEntity user) throw new UnauthorizedUserException("failed_login");
            Subscriptions client = (Subscriptions) client1;
            UserDto.CreateSubscriberClientDto clientDto = UserDto.CreateSubscriberClientDto.modelToDao(client);
            clientDto.setSecurityQuestionCounts(clientSecurityQuestionRepository.countBySubscriptions(client));

            if (client.getPasswordResetRequest() != null) {
                client.setPasswordResetRequest(null);
                subscriptionRepository.save(client);
            }
            Object jwtToken;
            if (!client.getFirstLogin()) {
                if (clientDto.getSecurityQuestionCounts() > 0) throw new UnauthorizedUserException("failed_login");
                OtpEntity otpParams = OtpEntity.builder()
                        .destination(client.getEmail())
                        .role(OtpEnum.FIRST_LOGIN)
                        .transport(client.getPreferedOtpChanel())
                        .guid(client.getUuid())
                        .build();
                List<Object> payloads = new ArrayList<>();
                payloads.add(UserDto.CreateSubscriberClientDto.modelToDao(client));
                CustomerVerification verificationObject = otpService.GenerateAndSend(otpParams, payloads, client);
                System.out.println("Exit2 >> Authentication Function");
                return new AuthResponse<>(clientDto, verificationObject);
            } else if (client.getDoubleAuthentication()) {
                OtpEntity otpParams = OtpEntity.builder()
                        .destination(client.getEmail())
                        .role(OtpEnum.LOGIN)
                        .guid(client.getUuid())
                        .build();
                CustomerVerification verificationObject = otpService.GenerateAndSend(otpParams, null, client);
                System.out.println("Exit2 >> Authentication Function");
                return new AuthResponse<>(clientDto, verificationObject);
            } else {
                jwtToken = jwtService.generateTokenForClient(client);
                System.out.println("Exit3 >> Authentication Function");
                return new AuthResponse<>(clientDto, jwtToken);
            }
        } catch (AuthenticationException | ResourceNotFoundException e) {
            throw new UnauthorizedUserException(e.getMessage());

        }

    }

    public String UpdatePassword(Subscriptions user, UpdatePasswordDto pass) throws ResourceNotFoundException {
//        PasswordConstraintValidator.isAcceptablePassword(pass.getConfirmPassword());
        Subscriptions subscriptions = findClientByUuid(user.getUuid());
        boolean isNewPass = pass.getNewPassword().matches(pass.getConfirmPassword());

        if (!isNewPass) {
            throw new ResourceNotFoundException("NewPassword does not match ConfirmPassword.");
        }
        boolean isPasswordMatch = passwordEncoder.matches(pass.getOldPassword(),
                subscriptions.getPassword());
        if (!isPasswordMatch) {
            throw new ResourceNotFoundException("Old Password does not match");
        }
        pass.setNewPassword(passwordEncoder.encode(pass.getConfirmPassword()));
        user.setPassword(pass.getNewPassword());
        subscriptionRepository.save(user);
        return "Updated";
    }


    public CustomerVerification forgotPassword(String login) throws UnauthorizedUserException, ResourceNotFoundException {
        var user = subscriptionRepository.findByUserLogin(login);
        if (user.isEmpty()) {
            throw new UnauthorizedUserException("User  does not Exist");
        }
        user.get().setPasswordResetRequest("INITIATED");
        subscriptionRepository.save(user.get());
        var result = UserDto.CreateSubscriberClientDto.modelToDao(user.get());
        var otpParams = OtpEntity.builder()
                .guid(user.get().getUuid())
                .expiresAt(TOOLS.Expiration())
                .role(OtpEnum.RESET_PASSWORD)
                .otp((long) OtpService.GenerateOtp())
                .sent(false)
                .destination(user.get().getPhoneNumber())
                .used(false)
                .build();
        return otpService.GenerateAndSend(otpParams, null, user.get());
    }

    public String updateClientProfile(UserDto.CreateSubscriberClientDto dto, String uuid, Subscriptions subs) throws ResourceNotFoundException, UnauthorizedUserException {
        Subscriptions subscriptions = findClientByUuid(subs.getUuid());
        dto.setId(subs.getId());
        ValidateConstraints(dto);
        subscriptions.setEmail(dto.getEmail());
        subscriptions.setPhoneNumber(dto.getPhoneNumber());
        subscriptions.setUserLogin(dto.getUserName());
        subscriptions.setPrimaryAccount(dto.getPrimaryAccount());
        subscriptions.setDoubleAuthentication(dto.getDoubleAuthentication());
        subscriptions.setPassExpiration(dto.getPassExpiration());
        subscriptions.setPassDuration(dto.getPassDuration());
        subscriptions.setAddress(dto.getAddress());
        subscriptions.setPassPeriodicity(dto.getPassPeriodicity());
        subscriptions.setPreferedOtpChanel(OtpChanel.valueOf(dto.getPreferredOtpChannel()));
        subscriptionRepository.save(subscriptions);
        return "Updated";

    }


    public void ValidateConstraints(UserDto.CreateSubscriberClientDto dto) throws ResourceNotFoundException, UnauthorizedUserException {
        PasswordConstraintValidator.isAcceptableTelephone(dto.getPhoneNumber());
        if (subscriptionRepository.findByUserLogin(dto.getUserName()).isPresent() && dto.getId() == null) {
            throw new ResourceNotFoundException("UserName Already Exist");
        }
        if (subscriptionRepository.findByPhoneNumber(dto.getPhoneNumber()).isPresent() && dto.getId() == null) {
            throw new ResourceNotFoundException("Phone Number Already Exist");
        }
        if (dto.getEmail().isEmpty())
            throw new ResourceNotFoundException("Make Sure You have an Email With the Institution Before Proceeding with Subscription");
        if (subscriptionRepository.findByEmail(dto.getEmail()).isPresent() && dto.getId() == null) {
            throw new ResourceNotFoundException("Email Already Exist");
        }
    }

    public List<Subscriptions> AllSubscribers() {
        return subscriptionRepository.findAll();
    }

    private Subscriptions ClientToSubscribe(UserDto.CreateSubscriberClientDto subDto, AccountEntityDto accountEntityDto, UserEntity subs) {
        subDto.setName(accountEntityDto.getClientName());
        subDto.setEmail(accountEntityDto.getEmail());
        subDto.setSubscriptionDate(String.valueOf(new Date(System.currentTimeMillis())));
        subDto.setPrimaryAccount(accountEntityDto.getAccountID());
        subDto.setClientMatricule(accountEntityDto.getClient());
        subDto.setProductName(accountEntityDto.getAccountName());
        subDto.setPreferredOtpChannel(OtpChanel.MAIL.name());
        subDto.setUserName(accountEntityDto.getEmail());
        subDto.setAddress(accountEntityDto.getAdresse1());
        subDto.setPhoneNumber(accountEntityDto.getMobile());
        subDto.setPassExpiration(false);
        subDto.setPassDuration(null);
        subDto.setPassPeriodicity(null);
        subDto.setDoubleAuthentication(false);

        return UserDto.CreateSubscriberClientDto.DtoToModel(subDto);
    }

    public AuthResponse<Object, Object> verifyFirstLogin(OtpAuth otp, String guid) throws ExpiredPasswordException, ResourceNotFoundException, UnauthorizedUserException {
        Optional<Subscriptions> client = subscriptionRepository.findByUuid(guid);
        if (client.isEmpty()) throw new UnauthorizedUserException("failed_login");
        if (client.get().getFirstLogin()) throw new UnauthorizedUserException("failed_login");
        try {
            otpService.VerifyOtp(otp, guid, client.get());
        } catch (Exception ex) {
            CustomerVerification verificationObject = institutionConfigService.countRemainingCustomerTrials(client.get());
            ClientVerification verify = ClientVerification.builder()
                    .subscriptions(client.get())
                    .status(Status.FAILED)
                    .verified(false)
                    .verificationType(VerificationType.OTP)
                    .message("failed_otp_verification")
                    .build();

            clientVerificationRepository.save(verify);
            throw new FailedSecurityVerification("failed_login",verificationObject );
        }

        client.get().setFirstLogin(true);
        Object jwtToken;
        jwtToken = jwtService.generateTokenForClient(client.get());
        subscriptionRepository.save(client.get());
        System.out.println("Exit3 >> Authentication Function");

        UserDto.CreateSubscriberClientDto clientDto = UserDto.CreateSubscriberClientDto.modelToDao(client.get());
        clientDto.setSecurityQuestionCounts(clientSecurityQuestionRepository.countBySubscriptions(client.get()));
        return new AuthResponse<>(clientDto, jwtToken);

    }

    public String resetPassword(String uuid, String guid, ForgotPasswordDto pass) throws UnauthorizedUserException, ResourceNotFoundException {
        var isValid = PasswordConstraintValidator.isAcceptablePassword(pass.getConfirmPassword());
        PasswordConstraintValidator.isAcceptablePassword(pass.getNewPassword());
        boolean isNewPass = pass.getNewPassword().matches(pass.getConfirmPassword());
        if (!isValid) {
            LOGGER.catching(new UnauthorizedUserException("Verify PasswordConstraintValidator Class"));
        }
        var isPassReset = pass.getNewPassword().equals(pass.getConfirmPassword());
        if (!isPassReset) {
            throw new UnauthorizedUserException("Password does not match.");
        }
        var user = subscriptionRepository.findByUuid(guid);
        if (user.isEmpty()) {
            throw new ResourceNotFoundException("User Uuid Not Found");
        }
        if (!Objects.equals(user.get().getPasswordResetRequest(), "ALLOWED")) {
            throw new UnauthorizedUserException("UNAUTHORIZED");
        }
        if (isNewPass) {
            user.get().setPassword(passwordEncoder.encode(pass.getConfirmPassword()));
            user.get().setPasswordResetRequest(null);
            user.get().setPasswordChangedTime(LocalDateTime.now());
            subscriptionRepository.save(user.get());
        } else {
            throw new UnauthorizedUserException("NewPassword does not match ConfirmPassword.");
        }

        return "success";
    }

    @Transactional
    public ClientVerification verifyResetPassRequest(String guid, OtpAuth otp) throws ExpiredPasswordException, ResourceNotFoundException, UnauthorizedUserException {
        Optional<Subscriptions> user = subscriptionRepository.findByUuid(guid);
        ClientVerification verify = new ClientVerification();
        if (user.isEmpty()) {
            throw new UnauthorizedUserException("UNAUTHORIZED1");
        }
        if (!Objects.equals(user.get().getPasswordResetRequest(), "INITIATED")) {
            throw new UnauthorizedUserException("UNAUTHORIZED2");
        }
        Boolean verified = otpService.VerifyOtp(otp, guid, user.get());
//        if (verified) {
//            user.get().setPasswordResetRequest("ALLOWED");
//            subscriptionRepository.save(user.get());
//            return verifys;
//        }
        return verify;
    }

    @Transactional
    public CustomerVerification subscribeRequest(SubscriptionRequestDto dao) throws SQLException, ResourceNotFoundException, BadAttributeValueExpException, UnauthorizedUserException {
        UserDto.CreateSubscriberClientDto dto = new UserDto.CreateSubscriberClientDto();
        List<AccountEntityDto> accountEntityDto = accountService.findClientAccounts(dao.getAccountId());
        if (accountEntityDto.size() > 1) {
            throw new ResourceNotFoundException("ERROR Contact Your Service Provider");
        }
        AccountEntityDto account = accountEntityDto
                .stream()
                .findFirst()
                .orElseThrow(() -> new ResourceNotFoundException(dao.getAccountId() + " Does Not Exist Please Make Sure you have an Account"));

        if (!Objects.equals(account.getMobile(), dao.getPhoneNumber()))
            throw new BadAttributeValueExpException(dao.getPhoneNumber() + "account_not_fount");
        if (!Objects.equals(account.getProductType(), dao.getAccountType()))
            throw new BadAttributeValueExpException(account.getProductType() + "account_not_fount");

        Subscriptions subscription;
        Optional<Subscriptions> subscriptionExist = subscriptionRepository.findByClientMatricul(account.getClientID());
        if (subscriptionExist.isPresent()) {
            if (Objects.equals(subscriptionExist.get().getStatus(), "ACTIVE"))
                throw new UnauthorizedUserException("customer_already_have_account");
            subscription = subscriptionExist.get();
        } else {
            subscription = ClientToSubscribe(dto, account, new UserEntity());
            subscription.setStatus("INACTIVE");
            subscription.setContactVerification(false);
            subscription.setFirstLogin(false);
            subscription = subscriptionRepository.save(subscription);
            subscriptionExist = subscriptionRepository.findByPhoneNumber(dao.getPhoneNumber());
            if (subscriptionExist.isPresent()) throw new UnauthorizedUserException("account_not_found_contact_admin");
        }

        OtpEntity params = new OtpEntity();
        params.setDestination(subscription.getPhoneNumber());
        params.setGuid(subscription.getUuid());
        params.setRole(OtpEnum.REGISTRATION_REQUEST);

        return otpService.GenerateAndSend(params, null, subscription);
    }


}
