package ibnk.service.BankingService;

import ibnk.dto.BankingDto.AccountMvtDto;
import ibnk.dto.BankingDto.AccountTransferDto;
import ibnk.dto.BankingDto.TransferModel.AccountCallback;
import ibnk.dto.BankingDto.TransferModel.MobilePayment;
import ibnk.repository.BankingRepository;
import ibnk.tools.error.ResourceNotFoundException;
import lombok.RequiredArgsConstructor;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Service;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Service
@RequiredArgsConstructor
public class MobilePaymentService {
    private final BankingRepository bankingRepository;

    public MobilePayment insertionMobilePayment(MobilePayment payement) throws SQLException, ResourceNotFoundException {
        Connection connection = bankingRepository.getConnection();
        String sql = "INSERT INTO MobilePayment(Uuid,Montant,CpteJumelle,Client,Telephone,Frais,Statut,PaymentGateWayUuid,Type,CallBackReceive,TypeOperation,TrxNumber,date) "
                + "VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?) ";
        try {
            PreparedStatement preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setString(1, payement.getUuid());
            preparedStatement.setFloat(2, payement.getMontant());
            preparedStatement.setString(3, payement.getCpteJumelle());
            preparedStatement.setString(4, payement.getClient());
            preparedStatement.setString(5, payement.getTelephone());
            preparedStatement.setFloat(6, payement.getFrais());
            preparedStatement.setString(7, payement.getStatut());
            preparedStatement.setString(8, payement.getPaymentGatewaysUuid());
            preparedStatement.setString(9, payement.getType());
            preparedStatement.setBoolean(10, payement.getCallBackReceive());
            preparedStatement.setString(11, payement.getTypeOperation());
            preparedStatement.setString(12, payement.getTrxNumber());
            preparedStatement.setString(13, payement.getDate());
            preparedStatement.executeUpdate();
            preparedStatement.close();
        } catch (SQLException ex) {
            throw new ResourceNotFoundException(ex.getMessage());
        } finally {
            System.out.println("Server ERROR");
        }
        return payement;
    }

    /* update table payment method */
    public MobilePayment updateMobilePayment(MobilePayment payement) throws SQLException, ResourceNotFoundException {
        Connection connection = bankingRepository.getConnection();
        String sql = "UPDATE MobilePayment set Statut=?,CallBackReceive=?,TrxNumber=?,Telephone=?, PaymentGatewayUuid = ? Where Uuid=? ";
        try {
            PreparedStatement preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setString(1, payement.getStatut());
            preparedStatement.setBoolean(2, payement.getCallBackReceive());
            preparedStatement.setString(3, payement.getTrxNumber());
            preparedStatement.setString(4, payement.getTelephone());
            preparedStatement.setString(5, payement.getPaymentGatewaysUuid());
            preparedStatement.setString(6, payement.getUuid());
            preparedStatement.executeUpdate();
            preparedStatement.close();
        } catch (SQLException e) {
            throw new ResourceNotFoundException(e.getMessage());
        }
//        finally {
//            fermeturesSilencieuses(resultSet, preparedStatement, connexion);
//        }
        return payement;
    }

    public AccountTransferDto account_callback(AccountCallback item) throws ResourceNotFoundException {
        SimpleJdbcCall call = new SimpleJdbcCall(bankingRepository.dataSource2()).withProcedureName("PS_MVT_ACCOUNTCALLBACK");
        MapSqlParameterSource in = new MapSqlParameterSource()
                .addValue("ws_Account", item.getAccount())
                .addValue("@pc_OutID", item.getTrxNumber())
                .addValue("@ws_Telephone", item.getTelephone())
                .addValue("pc_OutMSG", Types.VARCHAR)
                .addValue("pc_OutLECT", Types.INTEGER);
        Map<String, Object> out = call.execute(in);
        AccountTransferDto response = AccountTransferDto.TransferToDao(out);
        if (response.getPc_OutLECT() != 0) throw new ResourceNotFoundException(response.getPc_OutMSG());
        return response;
    }

    public List<MobilePayment> get_paymentUuid(String PaymentGatewayUuid) throws Exception {
        Connection connection = bankingRepository.getConnection();
            if (PaymentGatewayUuid == null || PaymentGatewayUuid.equals("")) {
                throw new Exception("PAYMENT UUID SHOULD NOT BE NULL");
            }
            String sqlQuery = "select * FROM MobilePayment where PaymentGatewayUuid=?";

            PreparedStatement preparedStatement = connection.prepareStatement(sqlQuery);
            preparedStatement.setString(1, PaymentGatewayUuid);
            ResultSet resultSet = preparedStatement.executeQuery();
            List<MobilePayment> result = new ArrayList<>();
            while (resultSet.next()) {
                MobilePayment mobilePayment = new MobilePayment();
                result.add(MobilePayment.modelToDao(mobilePayment, resultSet));
            }
            return result;
    }

    public List<MobilePayment> getPaymentBytUuidAndClient(String Uuid, String Client) throws Exception {
        Connection connection = bankingRepository.getConnection();
        if (Uuid == null || Uuid.equals("")) {
            throw new Exception("PAYMENT UUID SHOULD NOT BE NULL");
        }
        String sqlQuery = "select * FROM MobilePayment where Uuid=? AND Client=?";

        PreparedStatement preparedStatement = connection.prepareStatement(sqlQuery);
        preparedStatement.setString(1, Uuid);
        preparedStatement.setString(2, Client);
        ResultSet resultSet = preparedStatement.executeQuery();
        List<MobilePayment> result = new ArrayList<>();
        while (resultSet.next()) {
            MobilePayment mobilePayment = new MobilePayment();
            result.add(MobilePayment.modelToDao(mobilePayment, resultSet));
        }
        return result;
    }

    public AccountMvtDto account_mvt(AccountMvtDto item) throws ResourceNotFoundException {
        SimpleJdbcCall call = new SimpleJdbcCall(bankingRepository.dataSource2()).withProcedureName("PS_MVT_ACCOUNT");
        MapSqlParameterSource in = new MapSqlParameterSource()
                .addValue("ws_Account", item.getAccountId())
                .addValue("ws_Description", item.getDescription())
                .addValue("ws_Telephone", item.getPhoneNumber())
                .addValue("ws_Ids", item.getIds())
                .addValue("ws_onlineopdate", item.getDate())
                .addValue("ws_Amount", item.getAmount())
                .addValue("ws_Sens", item.getSens())
                .addValue("ws_TypeOp", item.getTypeOp())
                .addValue("pc_OutMSG", Types.VARCHAR)
                .addValue("pc_OutLECT", Types.INTEGER)
                .addValue("pc_OutID", Types.VARCHAR)
                .addValue("pc_state", Types.VARCHAR);
        Map<String, Object> out = call.execute(in);
        AccountMvtDto response = AccountMvtDto.TransferToDao(out);
        if (response.getPc_OutLECT() != 0)
            throw new ResourceNotFoundException(response.getPc_OutMSG());
        return response;

    }


}
