package ibnk.service.BankingService;

import ibnk.dto.AccountHistoryDto;
import ibnk.dto.BankingDto.*;
import ibnk.models.client.Subscriptions;
import ibnk.repository.BankingRepository;
import ibnk.tools.error.ResourceNotFoundException;
import lombok.RequiredArgsConstructor;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Service;

import java.sql.*;
import java.sql.Date;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;

@Service
@RequiredArgsConstructor
public class AccountService {

    private final BankingRepository bankingRepository;

    public AccountBalanceDto findAccountBalances(String ws_SenderAccount) throws ResourceNotFoundException {
        SimpleJdbcCall call = new SimpleJdbcCall(bankingRepository.dataSource2()).withProcedureName("PS_RETURN_ACCOUNT_BALANCES");
        MapSqlParameterSource in = new MapSqlParameterSource()
                .addValue("ws_SenderAccount", ws_SenderAccount);
        Map<String, Object> out = call.execute(in);
        AccountBalanceDto accountBalanceDto = AccountBalanceDto.modelToDao(out);
        if (accountBalanceDto.getPc_OutLECT() != 0)
            throw new ResourceNotFoundException(accountBalanceDto.getPc_OutMSG());
        return accountBalanceDto;
    }

    public AccountTransferDto account_transfer(AccountTransferDto item, Subscriptions subscription) throws SQLException, ResourceNotFoundException {
        SimpleJdbcCall call = new SimpleJdbcCall(bankingRepository.dataSource2()).withProcedureName("PS_MAKE_ACCOUNT_TRANSFERT");
        MapSqlParameterSource in = new MapSqlParameterSource()
                .addValue("ws_Client", subscription.getClientMatricul())
                .addValue("ws_SenderAccount", item.getAccountId())
                .addValue("ws_ReceiverAccount", item.getBeneficiary_account())
                .addValue("ws_Description", item.getMemo())
                .addValue("ws_Ids", item.getIds())
                .addValue("ws_onlineopdate", Date.valueOf(LocalDate.now()))
                .addValue("ws_Amount", item.getAmount());
        Map<String, Object> out = call.execute(in);
        AccountTransferDto response = AccountTransferDto.modelToDao(out);
        if (response.getPc_OutLECT() != 200) throw new ResourceNotFoundException(response.getPc_OutMSG());
        return response;
    }

    public BillingListDto amountBillingOptionWithVAT(BillingListDto item) throws ResourceNotFoundException {
        SimpleJdbcCall call = new SimpleJdbcCall(bankingRepository.dataSource2()).withProcedureName("RetAmountBillingOptionWithVAT");
        MapSqlParameterSource in = new MapSqlParameterSource()
                .addValue("Pd_ServerDate", item.getPd_ServerDate())
                .addValue("Pc_PrincipAccount", item.getPc_PrincipAccount())
                .addValue("Pc_SlaveAccount", item.getPc_SlaveAccount())
                .addValue("Pc_TypeOp", item.getPc_TypeOp())
                .addValue("Pc_CodeOp", item.getPc_CodeOp())
                .addValue("SvMontant", item.getSvMontant())
                .addValue("SvParaTx", item.getSvParaTx())
                .addValue("Language", item.getLanguage());
        Map<String, Object> out = call.execute(in);
        if ((Integer) out.get("lect") != 0) throw new ResourceNotFoundException((String) out.get("ErrMsg"));
        return BillingListDto.modeltodto(out);
    }

    public List<AccountEntityDto> findAllCustomersAccountBalances(String clientId) throws SQLException, ResourceNotFoundException {
        List<AccountEntityDto> accounts = findClientAccounts(clientId);
        for (AccountEntityDto accountEntityDto : accounts) {
            AccountBalanceDto balanceDto = findAccountBalances(accountEntityDto.getAccountID());
            accountEntityDto.setAvailableBalance(balanceDto.getAvailableBalance());
        }
        return accounts;
    }

    public List<BeneficiaryDto> findBeneficiaryByClientId(String clientId) throws SQLException {
        Connection connection = bankingRepository.getConnection();
        String sql = "select mb.id,mb.agence,mb.donneur,mb.beneficiaire,  \n" +
                "                mb.telephone,mb.cni, mb.nom, mb.onInstitution \n" +
                "                FROM  MobileBeneficiairy mb WHERE mb.client = ? ";
        PreparedStatement preparedStatement = connection.prepareStatement(sql);
        preparedStatement.setString(1, clientId);
        ResultSet resultSet = preparedStatement.executeQuery();
        List<BeneficiaryDto> result = new ArrayList<>();
        while (resultSet.next()) {
            BeneficiaryDto beneficiaryDto = new BeneficiaryDto();
            result.add(BeneficiaryDto.modelToDao(beneficiaryDto, resultSet));
        }
        return result;
    }

    public List<BeneficiaryDto> checkClientBeneficiary(String clientId, String benefAccountId) throws SQLException {
        Connection connection = bankingRepository.getConnection();
        String sql = "select cpt.agence, mb.donneur,  clt.Telephone1 telephone, clt.CNIPass cni, cpt.LibClient nom, cpt.CpteJumelle beneficiaire , mb.id, mb.onInstitution \n" +
                "FROM  CpteClt cpt \n" +
                "INNER JOIN ClientBnk clt on clt.client = cpt.Client\n" +
                "LEFT JOIN MobileBeneficiairy mb ON mb.client = ? and cpt.CpteJumelle = mb.beneficiaire\n" +
                "WHERE cpt.CpteJumelle = ?";
        PreparedStatement preparedStatement = connection.prepareStatement(sql);
        preparedStatement.setString(1, clientId);
        preparedStatement.setString(2, benefAccountId);
        ResultSet resultSet = preparedStatement.executeQuery();
        List<BeneficiaryDto> result = new ArrayList<>();
        while (resultSet.next()) {
            BeneficiaryDto beneficiaryDto = new BeneficiaryDto();
            result.add(BeneficiaryDto.modelToDao(beneficiaryDto, resultSet));
        }
        return result;
    }

    public String saveBeneficiary(BeneficiaryDto beneficiaryDto, Subscriptions subscriptions) throws SQLException, ResourceNotFoundException {
        Connection connection = bankingRepository.getConnection();
        Optional<BeneficiaryDto> beneficiaryInfo = checkClientBeneficiary(subscriptions.getClientMatricul(), beneficiaryDto.getBenefactorAccountNumber())
                .stream()
                .findFirst();
        if(beneficiaryInfo.isEmpty()) {
            throw new ResourceNotFoundException("account_not_found");
        }
        if(beneficiaryInfo.get().getId() > 0 ) {
            throw new ResourceNotFoundException("beneficiary_exist");
        }
        String insertQuery = "INSERT INTO MobileBeneficiairy (" +
                "[agence]\n" +
                "\t\t\t\t   ,[client]\n" +
                "\t\t\t\t   ,[donneur]\n" +
                "\t\t\t\t   ,[beneficiaire]\n" +
                "\t\t\t\t   ,[telephone]\n" +
                "\t\t\t\t   ,[nom]\n" +
                "\t\t\t\t   ,[onInstitution]\n" +
                "\t\t\t\t   ) " +
                "VALUES (?,?,?,?,?,?,?)";
        PreparedStatement insertStmt = connection.prepareStatement(insertQuery);
        insertStmt.setString(1, beneficiaryInfo.get().getAgence());
        insertStmt.setString(2, subscriptions.getClientMatricul());
        insertStmt.setString(3, subscriptions.getPrimaryAccount());
        insertStmt.setString(4, beneficiaryDto.getBenefactorAccountNumber());
        insertStmt.setString(5, beneficiaryInfo.get().getTelephone());
        insertStmt.setString(6, beneficiaryInfo.get().getNom());
        insertStmt.setString(7, "yes");
        insertStmt.executeUpdate();
        insertStmt.close();
        return "Sucess";
    }

    public BeneficiaryDto deleteBeneficiary(Integer beneficiaryId, Subscriptions user) throws SQLException, ResourceNotFoundException {
        SimpleJdbcCall call = new SimpleJdbcCall(bankingRepository.dataSource2()).withProcedureName("MB_Delete_Beneficiairy");
        MapSqlParameterSource in = new MapSqlParameterSource()
                .addValue("idTransaction", beneficiaryId)
                .addValue("client", user.getClientMatricul());
        Map<String, Object> out = call.execute(in);
        BeneficiaryDto accountBalanceDto = BeneficiaryDto.modelToDelete(out);
        if (accountBalanceDto.getLect() != 200)
            throw new ResourceNotFoundException(accountBalanceDto.getErrMsg());
        return accountBalanceDto;
    }

    public List<AccountEntityDto> findClientAccounts(String clientId) throws SQLException {
        Connection connection = bankingRepository.getConnection();
        String sql = "select clt.MobileType,clt.Eaccount,clt.passwordOperation,clt.email,clt.NomJumelle, Upper(Ltrim(Rtrim(p.ProductType))) ProductType,clt.Adresse1,clt.client, clt.Nom,clt.Prenom, clt.CNIPass, clt.TypeClient, clt.Telephone1, clt.Telephone2, cpt.CpteJumelle, cpt.Statut, cpt.CatCpte, cpt.LibCatCpte, cpt.Agence, cpt.LibAgence from CpteClt cpt\r\n" + //
                "inner join ClientBnk  clt on clt.client = cpt.Client\r\n" + //
                "inner join product p on cpt.catcpte=p.productcode and (p.visdep='Yes' or p.VisRet='Yes') And Upper(Ltrim(Rtrim(p.ProductType))) In ('SAVING','CURRENT')" + //
                "where cpt.Statut = 'Actif' and ( cpt.Client = ? OR cpt.CpteJumelle = ? )";
        PreparedStatement preparedStatement = connection.prepareStatement(sql);
        preparedStatement.setString(1, clientId);
        preparedStatement.setString(2, clientId);
        ResultSet resultSet = preparedStatement.executeQuery();
        List<AccountEntityDto> result = new ArrayList<>();
        while (resultSet.next()) {
            AccountEntityDto accountEntityDto = new AccountEntityDto();
            result.add(AccountEntityDto.modelToDao(accountEntityDto, resultSet));
        }
        return result;
    }

    public List<MobileBankConfigDto> findMbConfig() throws SQLException {
        Connection connection = bankingRepository.getConnection();
        String sql = "SELECT Code\n" +
                "      ,Description\n" +
                "      ,MaxPerDayToMobile\n" +
                "      ,NbMaxPerDayToMobile\n" +
                "      ,MaxPeMonthToMobile\n" +
                "      ,MaxPeWeekToMobile\n" +
                "      ,MaxAmtToMobile\n" +
                "      ,MaxAmtFromMobile\n" +
                "      ,MaxAmtTrfToAccount\n" +
                "      ,MaxPerDayTrfToAccount\n" +
                "      ,MinAmtTrfToAccount\n" +
                "      ,MinAmtToMobile\n" +
                "      ,MonthlyFee\n" +
                "      ,FraisAbonnement\n" +
                "  FROM MobileBankConfiguration";
        PreparedStatement preparedStatement = connection.prepareStatement(sql);
        ResultSet resultSet = preparedStatement.executeQuery();
        List<MobileBankConfigDto> result = new ArrayList<>();
        while (resultSet.next()) {
            MobileBankConfigDto mobileBankConfigDto = new MobileBankConfigDto();
            result.add(MobileBankConfigDto.modelToDao(mobileBankConfigDto, resultSet));
        }
        return result;
    }

    public MobileBankConfigDto findMbConfigByCode(String code) throws SQLException, ResourceNotFoundException {
        Connection connection = bankingRepository.getConnection();
        String sql = "SELECT Code\n" +
                "      ,Description\n" +
                "      ,MaxPerDayToMobile\n" +
                "      ,NbMaxPerDayToMobile\n" +
                "      ,MaxPeMonthToMobile\n" +
                "      ,MaxPeWeekToMobile\n" +
                "      ,MaxAmtToMobile\n" +
                "      ,MaxAmtFromMobile\n" +
                "      ,MaxAmtTrfToAccount\n" +
                "      ,MaxPerDayTrfToAccount\n" +
                "      ,MinAmtTrfToAccount\n" +
                "      ,MinAmtToMobile\n" +
                "      ,MonthlyFee\n" +
                "      ,FraisAbonnement\n" +
                "  FROM MobileBankConfiguration" +
                " WHERE Code = ?";
        PreparedStatement preparedStatement = connection.prepareStatement(sql);
        preparedStatement.setString(1, code);
        ResultSet resultSet = preparedStatement.executeQuery();
        List<MobileBankConfigDto> result = new ArrayList<>();
        while (resultSet.next()) {
            MobileBankConfigDto mobileBankConfigDto = new MobileBankConfigDto();
            result.add(MobileBankConfigDto.modelToDao(mobileBankConfigDto, resultSet));
        }
        return result.stream()
                .findFirst()
                .orElseThrow(() -> new ResourceNotFoundException("package_not_found"));
    }

    public double GetBalanceAtDate(String accountId, String date) throws SQLException {
        Connection connection = bankingRepository.getConnection();
        String sql = "select SUM(cptHist.Credit - cptHist.Debit ) balance  from CpteCltHist cptHist\r\n" + //
                "where  cptHist.CpteJumelle = ?  and cptHist.DateOperation <= ? ";
        PreparedStatement preparedStatement = connection.prepareStatement(sql);
        preparedStatement.setString(1, accountId);
        preparedStatement.setString(2, date);
        ResultSet resultSet = preparedStatement.executeQuery();
        double balance = 0.0; // Initialize with a default value
        if (resultSet.next()) {
            balance = resultSet.getDouble("balance");
        }
        return balance;
    }

    public AccountHistoryRes clientAccountHistory(AccountHistoryDto dto) throws SQLException {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");

        double OpeningBalance = GetBalanceAtDate(dto.getAccountId(), dto.getOpeningDate().format(formatter));
        double ClosingBallance = OpeningBalance;
        Connection connection = bankingRepository.getConnection();
        String sql = "SELECT cptHist.Description, cptHist.Txnno, cptHist.serie, cptHist.CpteJumelle , p.LibProduct,  cptHist.Credit, cptHist.Debit, cptHist.DateValeur, cptHist.DateOperation from CpteCltHist cptHist\r\n" + //
                "inner join product p on cptHist.catcpte = p.productcode and  Upper(Ltrim(Rtrim(p.ProductType))) In ('SAVING','CURRENT')" + //
                "WHERE cptHist.CpteJumelle = ?  and cptHist.DateOperation BETWEEN ? and ?  ORDER BY cptHist.DateOperation ASC, cptHist.serie ASC";
        PreparedStatement preparedStatement = connection.prepareStatement(sql);
        preparedStatement.setString(1, dto.getAccountId());
        preparedStatement.setString(2, dto.getOpeningDate().format(formatter));
        preparedStatement.setString(3, dto.getClosingDate().format(formatter));
        ResultSet resultSet = preparedStatement.executeQuery();
        List<ibnk.dto.BankingDto.AccountHistoryDto> result = new ArrayList<>();
        while (resultSet.next()) {
            ibnk.dto.BankingDto.AccountHistoryDto accountHistoryDto = new ibnk.dto.BankingDto.AccountHistoryDto();
            ClosingBallance = ClosingBallance + (resultSet.getDouble("Credit") - resultSet.getDouble("Debit"));
            result.add(ibnk.dto.BankingDto.AccountHistoryDto.modelToDao(accountHistoryDto, resultSet, ClosingBallance));
        }
        if(Objects.equals(dto.getTransactions(), "CREDIT")) {
            result = result.stream().filter(accountHistoryDto -> accountHistoryDto.getCredit() > 0).toList();
        } else if(Objects.equals(dto.getTransactions(), "DEBIT")) {
            result = result.stream().filter(accountHistoryDto -> accountHistoryDto.getDebit() > 0).toList();
        }
        AccountHistoryRes accountHistoryRes = new AccountHistoryRes();
        accountHistoryRes.setHistoryDto(result);
        accountHistoryRes.setOpeningBalance(OpeningBalance);
        accountHistoryRes.setClosingBalance(ClosingBallance);
        return accountHistoryRes;
    }

    public List<ibnk.dto.BankingDto.AccountHistoryDto> getClientActivity(AccountHistoryDto dao, String ClientMatricul) throws SQLException {
        Connection connection = bankingRepository.getConnection();
        String sql = "";
        if (dao.getAccountId().isEmpty()) {
            sql = "select Top(?) cptHist.Description, cptHist.Txnno, cptHist.serie, cpt.CpteJumelle, p.LibProduct,  cptHist.Credit, cptHist.Debit, cptHist.DateValeur, cptHist.DateOperation from CpteCltHist cptHist\r\n" + //
                    "inner join CpteClt cpt on cpt.CpteJumelle = cptHist.CpteJumelle " +//
                    "inner join product p on cpt.catcpte = p.productcode and (p.visdep='Yes' or p.VisRet='Yes') And Upper(Ltrim(Rtrim(p.ProductType))) In ('SAVING','CURRENT')" + //
                    "where  cptHist.Client = ?   " +//
                    "order by cptHist.serie desc ";

            PreparedStatement preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setInt(1, dao.getCount());
            preparedStatement.setString(2, ClientMatricul);
            ResultSet resultSet = preparedStatement.executeQuery();
            List<ibnk.dto.BankingDto.AccountHistoryDto> result = new ArrayList<>();
            while (resultSet.next()) {
                ibnk.dto.BankingDto.AccountHistoryDto accountHistoryDto = new ibnk.dto.BankingDto.AccountHistoryDto();
                result.add(ibnk.dto.BankingDto.AccountHistoryDto.modelToDao(accountHistoryDto, resultSet, 0.0));
            }
            return result;
        } else {
            sql = "select Top(?) cptHist.Description,  cptHist.serie,  cpt.CpteJumelle, p.LibProduct,  cptHist.Credit, cptHist.Debit, cptHist.DateValeur, cptHist.DateOperation from CpteCltHist cptHist\r\n" + //
                    "inner join CpteClt cpt on cpt.CpteJumelle = cptHist.CpteJumelle " +//
                    "inner join product p on cpt.catcpte = p.productcode and (p.visdep='Yes' or p.VisRet='Yes') And Upper(Ltrim(Rtrim(p.ProductType))) In ('SAVING','CURRENT')" + //
                    "where  cptHist.CpteJumelle = ?  and cptHist.DateOperation BETWEEN ? and ? " +//
                    "order by cptHist.serie desc ";

            PreparedStatement preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setInt(1, dao.getCount());
            preparedStatement.setString(2, dao.getAccountId());
            preparedStatement.setString(3, dao.getOpeningDate().toString());
            preparedStatement.setString(4, dao.getClosingDate().toString());
            ResultSet resultSet = preparedStatement.executeQuery();
            List<ibnk.dto.BankingDto.AccountHistoryDto> result = new ArrayList<>();
            while (resultSet.next()) {
                ibnk.dto.BankingDto.AccountHistoryDto accountHistoryDto = new ibnk.dto.BankingDto.AccountHistoryDto();
                result.add(ibnk.dto.BankingDto.AccountHistoryDto.modelToDao(accountHistoryDto, resultSet, 0.0));
            }
            return result;
        }
    }
}
