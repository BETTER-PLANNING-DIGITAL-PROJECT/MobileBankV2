package ibnk.service.BankingService;

import ibnk.dto.BankingDto.AccountBalanceDto;
import ibnk.dto.BankingDto.BillingListDto;
import ibnk.dto.BankingDto.PaymentDto;
import ibnk.dto.BankingDto.TransferModel.ExecutePayment;
import ibnk.dto.BankingDto.TransferModel.InitPayment;
import ibnk.dto.BankingDto.TransferModel.PayableResponse;
import ibnk.models.enums.ChannelCode;
import ibnk.service.BankingService.Bnkinterface.PaymentInterface;
import ibnk.tools.Interceptors.PayGateWayInterceptor;
import ibnk.tools.error.ResourceNotFoundException;
import lombok.RequiredArgsConstructor;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.reactive.function.BodyInserter;
import org.springframework.web.reactive.function.BodyInserters;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

import javax.annotation.PostConstruct;
import java.sql.*;
import java.util.Map;


@Service
@RequiredArgsConstructor
public class PaymentService implements PaymentInterface {
    private final RestTemplate restTemplate = new RestTemplate();

    @Value("${spring.http.url}")
    String URL;
    @Value("${spring.http.bearer}")
    String Bearer;
    @Value("${spring.http.publicKey}")
    String publicKey;

    WebClient webClient;

    @PostConstruct
    public void init() {
        webClient = WebClient.builder()
                .baseUrl(this.URL)
                .defaultHeaders(httpHeaders -> {
                    httpHeaders.add(HttpHeaders.AUTHORIZATION, this.Bearer);
                })
                .build();
    }

    @Override
    public PaymentDto initiatePayment(InitPayment body) {
        return webClient.post()
                .uri("/payment", uri -> uri.queryParam("publicKey", this.publicKey).build())
                .body(BodyInserters.fromValue(body))
                .retrieve()
                .onStatus(HttpStatusCode::is4xxClientError, clientResponse -> {
                    if (clientResponse.statusCode().equals(HttpStatus.UNAUTHORIZED)) {
                        return clientResponse.bodyToMono(String.class)
                                .doOnNext(System.out::println)
                                .then(Mono.error(new RuntimeException("Unauthorized")));
                    } else {
                        return clientResponse.bodyToMono(String.class)
                                .doOnNext(System.out::println)
                                .then(Mono.error(new RuntimeException("Some other 4xx error")));
                    }
                })
                .bodyToMono(PaymentDto.class)
                .block();
    }

    @Override
    public PaymentDto executePayment(ExecutePayment body, String uuid) {
        String url = "/payment/" + uuid;
        return webClient.put()
                .uri(url, uri -> uri.queryParam("publicKey", this.publicKey).build())
                .body(BodyInserters.fromValue(body))
                .retrieve()
                .onStatus(HttpStatusCode::is4xxClientError, clientResponse -> {
                    if (clientResponse.statusCode().equals(HttpStatus.UNAUTHORIZED)) {
                        return clientResponse.bodyToMono(String.class)
                                .doOnNext(System.out::println)
                                .then(Mono.error(new RuntimeException("Unauthorized")));
                    } else {
                        return clientResponse.bodyToMono(String.class)
                                .doOnNext(System.out::println)
                                .then(Mono.error(new RuntimeException("Some other 4xx error")));
                    }
                })
                .bodyToMono(PaymentDto.class)
                .block();
    }

    @Override
    public PaymentDto getPayment(String uuid) {
        String url = "/payment/" + uuid;
        return webClient.get()
                .uri(url, uri -> uri.queryParam("publicKey", this.publicKey).build())
                .retrieve()
                .onStatus(HttpStatusCode::is4xxClientError, clientResponse -> {
                    if (clientResponse.statusCode().equals(HttpStatus.UNAUTHORIZED)) {
                        return clientResponse.bodyToMono(String.class)
                                .doOnNext(System.out::println)
                                .then(Mono.error(new RuntimeException("Unauthorized")));
                    } else {
                        return clientResponse.bodyToMono(String.class)
                                .doOnNext(System.out::println)
                                .then(Mono.error(new RuntimeException("Some other 4xx error")));
                    }
                })
                .bodyToMono(PaymentDto.class)
                .block();
    }

    @Override
    public PayableResponse searchpayable(ChannelCode channel, String billId) {
        String url = "/payable/";
        return webClient.get()
                .uri(url, uri -> uri.queryParam("publicKey", this.publicKey)
                        .queryParam("channel", channel)
                        .queryParam("query", billId).build())
                .retrieve()
                .onStatus(HttpStatusCode::is4xxClientError, clientResponse -> {
                    if (clientResponse.statusCode().equals(HttpStatus.UNAUTHORIZED)) {
                        return clientResponse.bodyToMono(String.class)
                                .doOnNext(System.out::println)
                                .then(Mono.error(new RuntimeException("Unauthorized")));
                    } else {
                        return clientResponse.bodyToMono(String.class)
                                .doOnNext(System.out::println)
                                .then(Mono.error(new RuntimeException("Some other 4xx error")));
                    }
                })
                .bodyToMono(PayableResponse.class)
                .block();
    }


}
