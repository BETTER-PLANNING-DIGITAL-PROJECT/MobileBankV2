package ibnk.service;

import ibnk.models.ClientVerification;
import ibnk.models.client.Subscriptions;
import ibnk.repository.ClientVerificationRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@RequiredArgsConstructor
@Service
public class ClientVerificationService {

    private final ClientVerificationRepository clientVerificationRepository;




}
