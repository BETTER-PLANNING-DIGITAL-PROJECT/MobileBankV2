package ibnk.service;

import ibnk.dto.BankingDto.MobileBankConfigDto;
import ibnk.dto.UserDto;
import ibnk.dto.auth.ForgotPasswordDto;
import ibnk.dto.auth.OtpAuth;
import ibnk.dto.auth.UpdatePasswordDto;
import ibnk.models.UserEntity;
import ibnk.models.authorization.Roles;
import ibnk.models.enums.UserTypeEnum;
import ibnk.repository.*;
import ibnk.tools.error.ExpiredPasswordException;
import ibnk.tools.error.ResourceNotFoundException;
import ibnk.tools.error.UnauthorizedUserException;
import ibnk.tools.security.PasswordConstraintValidator;
import jakarta.transaction.Transactional;
import jakarta.validation.constraints.NotNull;
import lombok.RequiredArgsConstructor;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;


@Service()
@Transactional
@RequiredArgsConstructor
public class UserService {
    private final UserRepository userRepository;
    private final OtpRepository optRepository;
    private final OtpService otpService;
    public final PasswordEncoder passwordEncoder;
    private final ClientVerificationRepository clientVerificationRepository;
    private  final RolesRepo rolesRepo;
    private final BankingRepository bankingRepository;
    private final Logger LOGGER = LogManager.getLogger(UserService.class);

    public UserDto.EmployeeDto findEmployeeById (String employeeId) throws SQLException, ResourceNotFoundException {
        Connection connection = bankingRepository.getConnection();
        String sql = "SELECT Agence\n" +
                ",Matricule\n" +
                ",NomPrenom\n" +
                ",LibQualite\n" +
                ",Suspension\n" +
                ",Status\n" +
                "FROM [dbo].[Employe]\n" +
                "WHERE Matricule = ?";
        PreparedStatement preparedStatement = connection.prepareStatement(sql);
        preparedStatement.setString(1, employeeId);
        ResultSet resultSet = preparedStatement.executeQuery();
        List<UserDto.EmployeeDto> result = new ArrayList<>();
        while (resultSet.next()) {
            result.add(UserDto.EmployeeDto.DtoToModel(resultSet));
        }
        return result.stream()
                .findFirst()
                .orElseThrow(() -> new ResourceNotFoundException("employee_not_found"));

    }

    /**
     * @param uuid the uuid of the user
     * @return CreateUserDto
     * @throws ResourceNotFoundException not found
     */
    public UserEntity findUserByUuid(String uuid) throws ResourceNotFoundException {
        var user = userRepository.findUserByUuid(uuid);
        if (user.isEmpty()) {
            throw new ResourceNotFoundException("User does not Exist");
            // LOGGER.catching(throw new UnauthorizedUserException("User does not Exist"));
        }
        return user.get();
    }

    public String createUser(UserDto.CreateUserDto dao) throws UnauthorizedUserException, ResourceNotFoundException, SQLException {
        if (userRepository.findByUserLogin(dao.getUserLogin()).isPresent()) {
            throw new ResourceNotFoundException("user already Exist");
        }
        if (!Objects.equals(dao.getPassword(), dao.getConfirm_password())) {
            throw new ResourceNotFoundException("password_dont_match");
        }
        Optional<Roles> userRole = rolesRepo.findById(dao.getUserRoleId());
        if(userRole.isEmpty()) throw new ResourceNotFoundException("role_not_found");
        UserDto.EmployeeDto employee = findEmployeeById(dao.getUserLogin());
        var user = UserEntity.builder()
                .passExpiration(false)
                .userLogin(dao.getUserLogin())
                .branchCode(employee.getBranch())
                .name(employee.getEmployeeName())
                .role(userRole.get())
                .firstLogin(false)
                .password(passwordEncoder.encode(dao.getPassword()))
                .doubleAuthentication(false)
                .passDuration(dao.getPassDuration())
                .passPeriodicity(dao.getPassPeriodicity())
                .build();
        LOGGER.info("Enter >> register()");
        userRepository.save(user);
        return "successful";
    }

    @Transactional
    public UserDto.CreateUserDto updateUser(String uuid, UserDto.CreateUserDto dto) throws ResourceNotFoundException {
        UserEntity fnd = findUserByUuid(uuid);

        UserEntity updUser = UserDto.CreateUserDto.DtoToModel(dto);
        updUser.setPassword(fnd.getPassword());


        UserEntity val = userRepository.save(updUser);


        return UserDto.CreateUserDto.modelToDao(val);

    }

    /**
     * @param id
     * @return
     * @throws UnauthorizedUserException
     */
    public UserDto.CreateUserDto findById(long id) throws UnauthorizedUserException {
        var user = userRepository.findById(id);
        if (user.isEmpty()) {
            throw new UnauthorizedUserException("User does not Exist");
        }
        return UserDto.CreateUserDto.modelToDao(user.get());
    }

    /**
     * @param user
     * @param pass
     * @return
     * @throws UnauthorizedUserException
     */
    public UserEntity UpdatePassword(UserEntity user, UpdatePasswordDto pass) throws UnauthorizedUserException, ResourceNotFoundException {
        var isValid = PasswordConstraintValidator.isAcceptablePassword(pass.getConfirmPassword());
        if (!isValid) {
            LOGGER.catching(new UnauthorizedUserException("Verify PasswordConstraintValidator Class"));
        }
        boolean isNewPass = pass.getNewPassword().matches(pass.getConfirmPassword());
        if (!isNewPass) {
            throw new UnauthorizedUserException("NewPassword does not match ConfirmPassword.");
        }

        boolean isPasswordMatch = passwordEncoder.matches(pass.getOldPassword(),
                user.getPassword());
        if (!isPasswordMatch) {
            throw new UnauthorizedUserException("Old Password does not match");
        }
        pass.setNewPassword(passwordEncoder.encode(pass.getConfirmPassword()));
        user.setPassword(pass.getNewPassword());
        userRepository.save(user);
        return userRepository.save(user);
    }


    public UserEntity loadUserByUuid(String uuid) throws UsernameNotFoundException {
        LOGGER.info("Enter >> loadUserByUuiService");
        UserEntity user = userRepository.findUserByUuid(uuid).orElseThrow(() -> new UsernameNotFoundException("User not found"));
        LOGGER.info("Exit >> loadUserByUuiService");
        return user;
    }

}