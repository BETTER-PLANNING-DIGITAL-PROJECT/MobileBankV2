package ibnk.service;

import ibnk.dto.BankingDto.ClientQuestDto;
import ibnk.models.InstitutionConfig;
import ibnk.models.client.ClientSecurityQuestion;
import ibnk.models.client.SecurityQuestions;
import ibnk.models.client.Subscriptions;
import ibnk.repository.ClientSecurityQuestionRepository;
import ibnk.repository.SecurityQuestionRepository;
import ibnk.tools.error.ResourceNotFoundException;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@RequiredArgsConstructor
@Service
public class ClientSecurityQuestService {
    private final ClientSecurityQuestionRepository clientSecurityQuestionRepository;
    private final InstitutionConfigService institutionConfigService;
    public final PasswordEncoder passwordEncoder;
    private final SecurityQuestionRepository securityQuestionRepository;
    private final QuestionService questionService;


    @Transactional
    public String saveClientQuestion(List<ClientQuestDto> dto, Subscriptions subscription) throws ResourceNotFoundException {
        InstitutionConfig config = institutionConfigService.listConfig();
        List<ClientSecurityQuestion> clientSecurityQuestions = new ArrayList<>();
        if (dto.size() <= config.getMaxSecurityQuest() || dto.size() >= config.getMinSecurityQuest()) {
            dto.forEach(clientQuestDto -> {
                Optional<SecurityQuestions> question = securityQuestionRepository.findById(clientQuestDto.getSecurityQuestionId());
                if (question.isEmpty()) throw new RuntimeException("");
                ClientSecurityQuestion securityQuestion = new ClientSecurityQuestion();
                securityQuestion.setSubscriptions(subscription);
                securityQuestion.setSecurityAns(passwordEncoder.encode(clientQuestDto.getSecurityAns().toLowerCase()));
                securityQuestion.setSecurityQuestions(question.get());
                clientSecurityQuestions.add(securityQuestion);
            });
            updateClientQuestion(clientSecurityQuestions,subscription);
        } else {
            throw new ResourceNotFoundException("max or min Questions not respected");
        }
        return "Success";
    }

    @Transactional
//    @Transactional()
    public String updateClientQuestion(List<ClientSecurityQuestion> clientSecurityQuestions, Subscriptions subscription) {
        clientSecurityQuestionRepository.deleteClientSecurityQuestionsBySubscriptions(subscription);
        //deleteClientQuestion(clientSecurityQuestions);
        clientSecurityQuestionRepository.saveAll(clientSecurityQuestions);
        return "Updated";
    }

    private String deleteClientQuestion(List<ClientSecurityQuestion> clientSecurityQuestions) {
        clientSecurityQuestionRepository.deleteAll(clientSecurityQuestions);
        return "Deleted";
    }

    public void validateConstraint(Subscriptions subs, Long id) throws ResourceNotFoundException {

//        if (clientSecurityQuestionRepository.findClientSecurityQuestionBySubscriptionsAndId(subs, id).isPresent()) {
//            throw new ResourceNotFoundException("This Question has already been Assigned to the client");
//        }
    }
}
