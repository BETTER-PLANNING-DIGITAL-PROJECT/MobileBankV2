package ibnk.repository;

import ibnk.models.client.Subscriptions;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface SubscriptionRepository extends JpaRepository<Subscriptions,Long> {
    Optional<Subscriptions> findByUuid(String uuid);
    Optional<Subscriptions> findByUserLogin(String username);
    Optional<Subscriptions> findByPhoneNumber(String phone);
    Optional<Subscriptions> findByEmail(String mail);

    Optional<Subscriptions> findByClientMatricul(String clientMatricul);



}
