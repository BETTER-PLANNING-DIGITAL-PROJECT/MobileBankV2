package ibnk.repository;

import com.microsoft.sqlserver.jdbc.SQLServerDataSource;
import lombok.Getter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

@Service()
public class BankingRepository {
    @Getter
    private final DataSource dataSource;
    private SQLServerDataSource ds;
    @Value("${spring.datasource2.username}")
    private String username;
    @Value("${spring.datasource2.password}")
    private String password;
    @Value("${spring.datasource2.database}")
    private String database;
    @Value("${spring.datasource2.server}")
    private String server;
    @Value("${spring.datasource2.url}")
    private String url;
    @Autowired
    public BankingRepository(DataSource dataSource) {
        this.dataSource = dataSource;
    }
    public Connection getConnection() throws SQLException {
        return DriverManager.getConnection(url, username, password);
    }

    public DataSource dataSource2() {
        ds = new SQLServerDataSource();
        ds.setURL(url);
        ds.setUser(username);
        ds.setPassword(password);
        ds.setDatabaseName(database);
        ds.setServerName(server);
        return ds;
    }

}
