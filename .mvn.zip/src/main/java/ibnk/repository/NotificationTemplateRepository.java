package ibnk.repository;

import ibnk.models.NotificationTemplate;
import ibnk.models.enums.OtpChanel;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.transaction.annotation.Transactional;

import java.util.Optional;

public interface NotificationTemplateRepository extends JpaRepository<NotificationTemplate,Long> {
    Optional<NotificationTemplate> findById(Long id);
    Optional<NotificationTemplate> findByIdAndNotificationType(Long id,OtpChanel type);
    Optional<NotificationTemplate> findByNotificationTypeAndEventCode(OtpChanel typeNotification, String event);

}
