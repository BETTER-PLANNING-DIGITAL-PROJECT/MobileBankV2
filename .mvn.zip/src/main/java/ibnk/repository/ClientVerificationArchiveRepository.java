package ibnk.repository;

import ibnk.models.ClientVerificationArchive;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ClientVerificationArchiveRepository extends JpaRepository<ClientVerificationArchive,Long> {

}
