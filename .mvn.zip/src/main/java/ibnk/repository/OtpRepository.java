package ibnk.repository;

import ibnk.models.OtpEntity;
import ibnk.models.enums.OtpEnum;
import jakarta.transaction.Transactional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;

import java.util.Optional;

public interface OtpRepository extends JpaRepository<OtpEntity,Long> {
    Optional<OtpEntity> findByUuid(String uuid);
    Optional <OtpEntity> findByOtp(int otp);
    Optional<OtpEntity> findByRoleAndGuidAndUsed(OtpEnum role, String guid, Boolean used);
    Optional<OtpEntity> findByRoleAndGuid(OtpEnum role, String guid);
    Optional<OtpEntity> findByguidAndOtp(String Guid,int otp);

    @Modifying
    @Transactional
    void deleteByRoleAndDestinationAndGuid(OtpEnum role, String destination, String guid);
}
