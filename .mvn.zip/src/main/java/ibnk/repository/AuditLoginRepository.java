package ibnk.repository;

import ibnk.models.security.AuditLogin;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AuditLoginRepository extends JpaRepository<AuditLogin,Long> {
}
