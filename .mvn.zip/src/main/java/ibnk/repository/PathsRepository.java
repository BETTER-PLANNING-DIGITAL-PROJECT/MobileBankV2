package ibnk.repository;

import ibnk.models.UserEntity;
import ibnk.models.authorization.AppPaths;
import ibnk.models.enums.PathType;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.Set;

public interface PathsRepository extends JpaRepository<AppPaths,Long> {
    Optional<AppPaths> findByIdAndType(Long id, PathType type);

    Optional<ArrayList<AppPaths>> findByType(PathType type);
    Optional<AppPaths> findByIdAndParent(Long id, AppPaths parent);

    Optional<AppPaths> findByIdAndModule(Long id, AppPaths module);
}
