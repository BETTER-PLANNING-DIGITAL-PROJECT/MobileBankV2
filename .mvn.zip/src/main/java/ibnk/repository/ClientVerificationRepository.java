package ibnk.repository;

import ibnk.models.ClientVerification;
import ibnk.models.client.Subscriptions;
import ibnk.models.enums.Status;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.sql.Date;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

public interface ClientVerificationRepository extends JpaRepository<ClientVerification,Long> {
    Optional<ClientVerification> findByUuid(String uuid);

    @Query("SELECT COUNT(v.id) FROM  ClientVerification v  WHERE v.subscriptions =?1 and v.status = ?2 and v.createdAt >= ?3")
    Integer countPreviousFailedTrials(@Param("client") Subscriptions client, @Param("status") Status status, @Param("time") LocalDateTime date);

    List<ClientVerification> findClientVerificationBySubscriptions(Subscriptions subscriptions);

}
