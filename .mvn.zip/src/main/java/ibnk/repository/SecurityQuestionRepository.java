package ibnk.repository;

import ibnk.models.client.SecurityQuestions;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface SecurityQuestionRepository extends JpaRepository<SecurityQuestions,Long> {


}
