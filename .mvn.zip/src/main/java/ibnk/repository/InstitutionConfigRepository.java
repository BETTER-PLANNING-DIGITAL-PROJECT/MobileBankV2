package ibnk.repository;

import ibnk.models.InstitutionConfig;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface InstitutionConfigRepository extends JpaRepository<InstitutionConfig,Long> {

}
