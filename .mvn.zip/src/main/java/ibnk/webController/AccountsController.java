package ibnk.webController;

import ibnk.dto.AccountHistoryDto;
import ibnk.dto.BankingDto.AccountBalanceDto;
import ibnk.dto.BankingDto.AccountEntityDto;
import ibnk.dto.BankingDto.AccountHistoryRes;
import ibnk.models.enums.RangeSelector;
import ibnk.service.BankingService.AccountService;
import ibnk.tools.ResponseHandler;
import ibnk.tools.TOOLS;
import ibnk.tools.error.ResourceNotFoundException;
import ibnk.tools.error.UnauthorizedUserException;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.sql.SQLException;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.List;

@RequiredArgsConstructor
@RestController
@CrossOrigin
@RequestMapping("/api/v1/admin/accounts")
public class AccountsController {
    private final AccountService accountService;

    @PostMapping("find/{accountId}")
    public ResponseEntity<Object> findClientAccount(@PathVariable String accountId) throws UnauthorizedUserException, SQLException {
        List<AccountEntityDto> cus = accountService.findClientAccounts(accountId);
        return ResponseHandler.generateResponse(HttpStatus.OK, true, "Success", cus);
    }

    @GetMapping("getBalances/{accountId}")
            public ResponseEntity<Object> accountBalance(@PathVariable String accountId) throws UnauthorizedUserException, SQLException, ResourceNotFoundException {
        AccountBalanceDto cus = accountService.findAccountBalances(accountId);
        return ResponseHandler.generateResponse(HttpStatus.OK, true, "Success", cus);
    }

//    @PostMapping("getStatement")
//    public ResponseEntity<Object> ListAllAccountHistory(@RequestBody AccountHistoryDto dao) throws SQLException {
//        AccountHistoryRes hist = new AccountHistoryRes();
//        switch (RangeSelector.valueOf(dao.getRangeSelector())) {
//            case THIS_MONTH -> {
//                dao.setOpeningDate(TOOLS.firstDayOfThisMonth());
//                dao.setClosingDate(new Date().toString());
//                hist = accountService.clientAccountHistory(dao);
//            }
//            case PREVIOUS_MONTH -> {
//                dao.setOpeningDate(TOOLS.firstDayOfPreviousMonth().toString());
//                dao.setClosingDate(TOOLS.lastDayOfPreviousMonth().toString());
//                hist = accountService.clientAccountHistory(dao);
//            }
//            case PREVIOUS_QUARTER -> {
//                dao.setOpeningDate(TOOLS.firstDayOfPreviousQuarterMonth().toString());
//                dao.setClosingDate(TOOLS.lastDayOfPreviousQuarterMonth().toString());
//                hist = accountService.clientAccountHistory(dao);
//            }
//        }
//        return ResponseHandler.generateResponse(HttpStatus.OK, false, "success", hist);
//    }


}
