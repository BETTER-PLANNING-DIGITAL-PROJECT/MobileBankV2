package ibnk.webController;

import ibnk.dto.auth.OtpAuth;
import ibnk.models.enums.OtpEnum;
import ibnk.service.OtpService;
import ibnk.service.UserService;
import ibnk.tools.ResponseHandler;
import ibnk.tools.error.ExpiredPasswordException;
import ibnk.tools.error.ResourceNotFoundException;
import ibnk.tools.error.UnauthorizedUserException;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/admin/auth/otp")
@RequiredArgsConstructor
@CrossOrigin
public class OtpController {
    private final OtpService otpService;

//    @GetMapping("/resend/{uuid}")
//    public ResponseEntity<Object> ResendOtp(@PathVariable(value = "uuid") String uuid) throws ResourceNotFoundException {
//        var result = otpService.ResendOtp(uuid);
//        return ResponseHandler.generateResponse(HttpStatus.OK, true, "Success", result);
//    }


    @PostMapping("/VerifyOtp/{guid}")
    public ResponseEntity<Object> VerifyOtpResetPassword(@PathVariable(value = "guid") String guid, OtpAuth otp) throws ResourceNotFoundException, UnauthorizedUserException, ExpiredPasswordException, ExpiredPasswordException {
        var result = false;
        switch (OtpEnum.valueOf(otp.getRole())){

        }
        return ResponseHandler.generateResponse(HttpStatus.OK, true, "Success", result);
    }
}

