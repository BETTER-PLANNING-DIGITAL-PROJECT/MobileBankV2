package ibnk.webController.client;

import org.springframework.http.codec.ServerSentEvent;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.method.annotation.SseEmitter;
import reactor.core.publisher.Flux;

import java.io.IOException;
import java.util.concurrent.atomic.AtomicBoolean;

@RestController
@CrossOrigin
@RequestMapping("/api/v1/client/events")
public class SSEController {

    private AtomicBoolean operationCompleted = new AtomicBoolean(false);

    @GetMapping(value = "/transaction/{uuid}",  produces = "text/event-stream")
    public Flux<ServerSentEvent<String>> streamEvents(@PathVariable String uuid) throws IOException {
        if(operationCompleted.get()) {
            operationCompleted.set(false);
            return Flux.just(ServerSentEvent.<String>builder()
                            .id("1")
                            .event("message")
                            .data("Operation Completed")
                            .build())
                    .concatWith(Flux.empty());
        }
        return Flux.empty();
    }

    // Method to send events
    public void sendTransactionEvent(Object data, String name) {
        operationCompleted.set(true);
    }
}
