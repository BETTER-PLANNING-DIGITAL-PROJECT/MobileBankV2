package ibnk.webController.client;

import ibnk.dto.BankingDto.ClientQuestDto;
import ibnk.dto.auth.CustomerVerification;
import ibnk.models.ClientVerification;
import ibnk.models.InstitutionConfig;
import ibnk.models.client.SecurityQuestions;
import ibnk.models.client.Subscriptions;
import ibnk.models.enums.Status;
import ibnk.repository.ClientSecurityQuestionRepository;
import ibnk.repository.ClientVerificationRepository;
import ibnk.repository.SecurityQuestionRepository;
import ibnk.service.ClientSecurityQuestService;
import ibnk.service.CustomerService;
import ibnk.service.InstitutionConfigService;
import ibnk.tools.Interceptors.InterceptQuestions;
import ibnk.tools.ResponseHandler;
import ibnk.tools.error.ResourceNotFoundException;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;
@RequiredArgsConstructor
@RestController
@CrossOrigin
@RequestMapping("/api/v1/client/config")
public class ConfigClientController {

    private final ClientSecurityQuestService clientSecurityQuestService;
    private final ClientSecurityQuestionRepository clientSecurityQuestionRepository;
    private final SecurityQuestionRepository securityQuestionRepository;
    private final InstitutionConfigService institutionConfigService;
    private final CustomerService customerService;
    private final ClientVerificationRepository clientVerificationRepository;

    @GetMapping
    public ResponseEntity<Object> listInstConfig() throws ResourceNotFoundException {
        InstitutionConfig institutionConfig = institutionConfigService.listConfig();
        return ResponseHandler.generateResponse(HttpStatus.OK, true, "Success", institutionConfig);

    }
    @PostMapping("/setSecurityQuestions")
    public ResponseEntity<Object> setSecurityQuestions(@RequestBody List<ClientQuestDto> dto, @AuthenticationPrincipal Subscriptions subs) throws ResourceNotFoundException {
        String response = clientSecurityQuestService.saveClientQuestion(dto,subs);
        return ResponseHandler.generateResponse(HttpStatus.OK, false, "success", response);
    }

    @InterceptQuestions
    @PostMapping("/updateSecurityQuestions")
    public ResponseEntity<Object> updateSecurityQuestions(@RequestBody List<ClientQuestDto> dto, @AuthenticationPrincipal Subscriptions subs) throws ResourceNotFoundException {
        String response = clientSecurityQuestService.saveClientQuestion(dto,subs);
        return ResponseHandler.generateResponse(HttpStatus.OK, false, "success", response);
    }

    @GetMapping("/listSecurityQuestions")
    public ResponseEntity<Object> listSecurityQuestions( @AuthenticationPrincipal Subscriptions subs) throws ResourceNotFoundException {
        List<SecurityQuestions> response = securityQuestionRepository.findAll();
        return ResponseHandler.generateResponse(HttpStatus.OK, false, "success", response);
    }

    @GetMapping("/getVerificationQuestions")
    public ResponseEntity<Object> listVerificationQuestion( @AuthenticationPrincipal Subscriptions subs) throws ResourceNotFoundException {
        InstitutionConfig config = institutionConfigService.listConfig();
        List<SecurityQuestions> response = clientSecurityQuestionRepository.listClientSecurityQuestionsRandomly(subs.getId()).subList(0, config.getVerifyQuestNumber());

        LocalDateTime time =  LocalDateTime.now().minusMinutes(config.getVerificationResetTimer());
        Integer previousTrials = clientVerificationRepository.countPreviousFailedTrials(subs, Status.FAILED, time);
        Integer leftTrials = Math.toIntExact(config.getMaxVerifyAttempt() - previousTrials);
        CustomerVerification responseData = new CustomerVerification();

        responseData.setVerificationObject(response);
        responseData.setTrials(leftTrials);
        responseData.setMaxTrials(Math.toIntExact(config.getMaxVerifyAttempt()));
        responseData.setVerificationType("SECURE_QUESTIONS");
        return ResponseHandler.generateResponse(HttpStatus.OK, false, "success", responseData);
    }

    @PostMapping("/verifySecurityQuestions")
    public ResponseEntity<Object> verifySecurityQuestions(@RequestBody List<ClientQuestDto> dto, @AuthenticationPrincipal Subscriptions subs) throws ResourceNotFoundException {
        ClientVerification response = institutionConfigService.verifySecurityQuestions(dto,subs);
        return ResponseHandler.generateResponse(HttpStatus.OK, false, "success", response);
    }
}
