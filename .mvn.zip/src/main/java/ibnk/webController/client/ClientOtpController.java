package ibnk.webController.client;

import ibnk.dto.auth.OtpAuth;
import ibnk.models.client.Subscriptions;
import ibnk.models.enums.OtpEnum;
import ibnk.service.OtpService;
import ibnk.tools.ResponseHandler;
import ibnk.tools.error.ResourceNotFoundException;
import ibnk.tools.error.UnauthorizedUserException;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/client/otp")
@RequiredArgsConstructor
@CrossOrigin
public class ClientOtpController {
    private final OtpService otpService;
    private final TransactionController transactionController;



    @PostMapping("/verify/{guid}")
    public ResponseEntity<Object> VerifyOtpResetPassword(@AuthenticationPrincipal Subscriptions subscription, @PathVariable(value = "guid") String guid, @RequestBody OtpAuth otp) throws Exception {
      boolean otpValidation = otpService.VerifyOtp(otp,guid, subscription);
      if(otpValidation) {
          switch (OtpEnum.valueOf(otp.getRole())) {
              case  VALIDATE_TRANSACTION -> {
                  return transactionController.validatedInitiatedOperation(subscription, guid);
              }
          }
          throw new UnauthorizedUserException("");
      }
        throw new UnauthorizedUserException("");
    }
}

