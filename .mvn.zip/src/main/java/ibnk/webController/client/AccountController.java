package ibnk.webController.client;
import ibnk.dto.AccountHistoryDto;
import ibnk.dto.BankingDto.AccountBalanceDto;
import ibnk.dto.BankingDto.AccountEntityDto;
import ibnk.dto.BankingDto.AccountHistoryRes;
import ibnk.dto.BankingDto.BeneficiaryDto;
import ibnk.models.client.Subscriptions;
import ibnk.models.enums.RangeSelector;
import ibnk.service.BankingService.AccountService;
import ibnk.service.CustomerService;
import ibnk.tools.Interceptors.InterceptQuestions;
import ibnk.tools.ResponseHandler;
import ibnk.tools.TOOLS;
import ibnk.tools.error.ResourceNotFoundException;
import ibnk.tools.error.UnauthorizedUserException;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

@RequiredArgsConstructor
@RestController
@CrossOrigin
@RequestMapping("/api/v1/client/accounts")
public class AccountController {
    private final AccountService accountService;
    private final CustomerService customerService;

    @GetMapping("/getMbToken")
    public ResponseEntity<Object> GetAccessToken(@AuthenticationPrincipal Subscriptions subscriptions) throws Exception {
        String subs  = TOOLS.generateAccessToken(subscriptions);
        return ResponseHandler.generateResponse(HttpStatus.OK, false, "success", subs);

    }


    @CrossOrigin
    @GetMapping("listAll")
    public ResponseEntity<Object> findClientAccount(@AuthenticationPrincipal Subscriptions subscriber) throws UnauthorizedUserException, SQLException {
        List<AccountEntityDto> cus = accountService.findClientAccounts(subscriber.getClientMatricul());
        return ResponseHandler.generateResponse(HttpStatus.OK, true, "Success", cus);
    }

    @GetMapping("getDetails/{accountId}")
    public ResponseEntity<Object> getAccountBalance(@PathVariable String accountId) throws UnauthorizedUserException, SQLException, ResourceNotFoundException {
        AccountBalanceDto cus = accountService.findAccountBalances(accountId);
        return ResponseHandler.generateResponse(HttpStatus.OK, true, "Success", cus);
    }

    @GetMapping("getDetails")
    public ResponseEntity<Object> getAllAccountsDetails(@AuthenticationPrincipal Subscriptions subscriber) throws UnauthorizedUserException, SQLException, ResourceNotFoundException {
        List<AccountEntityDto> cus = accountService.findAllCustomersAccountBalances(subscriber.getClientMatricul());
        return ResponseHandler.generateResponse(HttpStatus.OK, true, "Success", cus);
    }

    @PostMapping("getStatement")
    public ResponseEntity<Object> ListAllAccountHistory(@RequestBody AccountHistoryDto dao) throws SQLException {
        DateTimeFormatter customPattern = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        switch (RangeSelector.valueOf(dao.getRangeSelector())) {
            case THIS_MONTH -> {
                dao.setOpeningDate(TOOLS.firstDayOfThisMonth());
                dao.setClosingDate(LocalDate.now());
            }
            case PREVIOUS_MONTH -> {
                dao.setOpeningDate(TOOLS.firstDayOfPreviousMonth());
                dao.setClosingDate(TOOLS.lastDayOfPreviousMonth());
            }
            case PREVIOUS_QUARTER -> {
                dao.setOpeningDate(TOOLS.firstDayOfPreviousQuarterMonth());
                dao.setClosingDate(TOOLS.lastDayOfPreviousQuarterMonth());
            }
        }
        AccountHistoryRes accountHistoryRes  = accountService.clientAccountHistory(dao);
        return ResponseHandler.generateResponse(HttpStatus.OK, false, "success", accountHistoryRes);
    }

    @PostMapping("getRecentActivity")
    public ResponseEntity<Object> ListRecentActivity(@RequestBody AccountHistoryDto dao, @AuthenticationPrincipal Subscriptions subscriber) throws SQLException {
        var hist = accountService.getClientActivity(dao, subscriber.getClientMatricul());
        return ResponseHandler.generateResponse(HttpStatus.OK, false, "success", hist);
    }

    @GetMapping("findAccount/{accountId}")
    public ResponseEntity<Object> findAccountByAccountNumber(@PathVariable String accountId) throws UnauthorizedUserException, SQLException, ResourceNotFoundException {
        List<AccountEntityDto> cus = accountService.findClientAccounts(accountId);
        if(cus.isEmpty()) throw new ResourceNotFoundException("account_not_found");
        if(cus.size() > 1) throw new ResourceNotFoundException("account_not_found");
        return ResponseHandler.generateResponse(HttpStatus.OK, true, "Success", cus.get(0));
    }

    @InterceptQuestions
    @PostMapping("save-beneficiary")
    public ResponseEntity<Object> getBeneficiary(@RequestBody BeneficiaryDto beneficiaryDto, @AuthenticationPrincipal Subscriptions subscriber) throws UnauthorizedUserException, SQLException, ResourceNotFoundException {
        String cus = accountService.saveBeneficiary(beneficiaryDto,subscriber);
        return ResponseHandler.generateResponse(HttpStatus.OK, true, "Success", cus);
    }

    @GetMapping("list-beneficiaries")
    public ResponseEntity<Object> getAllBeneficiaryDetails(@AuthenticationPrincipal Subscriptions subscriber) throws UnauthorizedUserException, SQLException {
        List<BeneficiaryDto> cus = accountService.findBeneficiaryByClientId(subscriber.getClientMatricul());
        return ResponseHandler.generateResponse(HttpStatus.OK, true, "Success", cus);
    }

    @InterceptQuestions
    @DeleteMapping("delete-beneficiary/{id}")
    public ResponseEntity<Object> deleteBeneficiary(@PathVariable Integer id, @AuthenticationPrincipal Subscriptions subscriber) throws UnauthorizedUserException, SQLException, ResourceNotFoundException {
        BeneficiaryDto cus = accountService.deleteBeneficiary(id, subscriber);
        return ResponseHandler.generateResponse(HttpStatus.OK, true, "Success", cus);
    }
}
