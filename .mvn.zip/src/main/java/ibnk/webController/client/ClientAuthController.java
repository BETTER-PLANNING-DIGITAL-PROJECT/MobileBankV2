package ibnk.webController.client;

import ibnk.dto.SubscriptionRequestDto;
import ibnk.dto.UserDto;
import ibnk.dto.auth.*;
import ibnk.models.client.Subscriptions;
import ibnk.models.enums.OtpEnum;
import ibnk.service.CustomerService;
import ibnk.tools.Interceptors.InterceptQuestions;
import ibnk.tools.ResponseHandler;
import ibnk.tools.error.ExpiredPasswordException;
import ibnk.tools.error.ResourceNotFoundException;
import ibnk.tools.error.UnauthorizedUserException;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import javax.management.BadAttributeValueExpException;
import java.sql.SQLException;

@RequiredArgsConstructor
@RestController
@CrossOrigin
@RequestMapping("/api/v1/client")
public class ClientAuthController {
    private final CustomerService customerService;
    private final SSEController sseController;


    @PostMapping("/auth/authenticate")
    public ResponseEntity<Object> authentication(@Valid @RequestBody AuthDto auth) throws UnauthorizedUserException, ResourceNotFoundException {
        var resource = customerService.authenticate(auth);
        sseController.sendTransactionEvent(resource,"test");
        return ResponseHandler.generateResponse(HttpStatus.OK, true, "Success", resource);
    }

    @CrossOrigin
    @GetMapping("/auth/forgot/password/{login}")
    public ResponseEntity<Object> ForgotUserPassword(@PathVariable String login) throws UnauthorizedUserException, ResourceNotFoundException {
        var otp = customerService.forgotPassword(login);
        return ResponseHandler.generateResponse(HttpStatus.OK, true, "Success", otp);
    }

//    @GetMapping("/auth/resendOtp/{uuid}")
//    public ResponseEntity<Object> ResendOtp(@PathVariable(value = "uuid") String uuid) throws ResourceNotFoundException {
//        var result = otpService.ResendOtp(uuid);
//        return ResponseHandler.generateResponse(HttpStatus.OK, true, "Success", result);
//    }

    @PostMapping("/auth/verifyOtp/{guid}")
    public ResponseEntity<Object> VerifyOtpResetPasswordAndFirstLogin(@PathVariable(value = "guid") String guid, @RequestBody OtpAuth otp) throws ResourceNotFoundException, UnauthorizedUserException, ExpiredPasswordException, ExpiredPasswordException {
        Object result = new Object();
        switch (OtpEnum.valueOf(otp.getRole())){
            case  RESET_PASSWORD -> {
                result = customerService.verifyResetPassRequest(guid, otp);
            }
            case FIRST_LOGIN -> {
                result = customerService.verifyFirstLogin(otp, guid);
            }
        }
        return ResponseHandler.generateResponse(HttpStatus.OK, true, "Success", result);
    }

    @PostMapping("resetPassword/{guid}")
    public ResponseEntity<Object> ResetPassword(@RequestHeader("X-Verification-Key") String uuid,@PathVariable(value = "guid") String guid, @RequestBody ForgotPasswordDto pass) throws ResourceNotFoundException, UnauthorizedUserException {
        var otp = customerService.resetPassword(uuid,guid, pass);
        return ResponseHandler.generateResponse(HttpStatus.OK, true, "Success", otp);
    }

    @PutMapping("/updateProfile")
    public ResponseEntity<Object> updateProfile(@RequestHeader("X-Verification-Key") String uuid, @RequestBody UserDto.CreateSubscriberClientDto dto, @AuthenticationPrincipal Subscriptions subs) throws ResourceNotFoundException, UnauthorizedUserException {
        var response = customerService.updateClientProfile(dto,uuid,subs);
        return ResponseHandler.generateResponse(HttpStatus.OK, false, "success", response);
    }

    @InterceptQuestions
    @PutMapping("/updatePassword")
    public ResponseEntity<Object> updatePassword(@AuthenticationPrincipal Subscriptions subscriptions,@RequestBody UpdatePasswordDto dto) throws ResourceNotFoundException, UnauthorizedUserException {
        var response = customerService.UpdatePassword(subscriptions,dto);
        return ResponseHandler.generateResponse(HttpStatus.OK, false, "success", response);
    }

    @PostMapping("/auth/subscription/request")
    public ResponseEntity<Object> getAccountBalance(@RequestBody SubscriptionRequestDto dto) throws UnauthorizedUserException, SQLException, ResourceNotFoundException, BadAttributeValueExpException {
        CustomerVerification verification = customerService.subscribeRequest(dto);
        return ResponseHandler.generateResponse(HttpStatus.OK, true, "Success", verification);
    }


}
