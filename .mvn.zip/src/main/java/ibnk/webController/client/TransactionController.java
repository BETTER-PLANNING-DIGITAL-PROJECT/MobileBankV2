package ibnk.webController.client;

import com.fasterxml.jackson.databind.ObjectMapper;
import ibnk.dto.BankingDto.*;
import ibnk.dto.BankingDto.TransferModel.*;
import ibnk.dto.UserDto;
import ibnk.dto.auth.CustomerVerification;
import ibnk.models.OtpEntity;
import ibnk.models.client.Subscriptions;
import ibnk.models.enums.ChannelCode;
import ibnk.models.enums.OtpChanel;
import ibnk.models.enums.OtpEnum;
import ibnk.models.enums.PaymentType;
import ibnk.service.BankingService.AccountService;
import ibnk.service.BankingService.MobilePaymentService;
import ibnk.service.BankingService.PaymentService;
import ibnk.service.OtpService;
import ibnk.tools.Interceptors.InterceptQuestions;
import ibnk.tools.ResponseHandler;
import ibnk.tools.error.ResourceNotFoundException;
import lombok.RequiredArgsConstructor;
import org.json.JSONObject;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.codec.ServerSentEvent;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Flux;

import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.atomic.AtomicBoolean;


@RequiredArgsConstructor
@RestController
@CrossOrigin
@RequestMapping("/api/v1/client/transactions")
public class TransactionController {
    private final AccountService accountService;
    private final MobilePaymentService mobilePaymentService;
    private final PaymentService paymentService;
    private final OtpService otpService;
    private final SSEController sseController;

    private final AtomicBoolean operationCompleted = new AtomicBoolean(false);

    @InterceptQuestions
    @PostMapping("internalTransfer")
    public ResponseEntity<Object> makeTransfer(@RequestBody AccountTransferDto dao, @AuthenticationPrincipal Subscriptions subscription) throws SQLException, ResourceNotFoundException {
        var trans = accountService.account_transfer(dao, subscription);
        return ResponseHandler.generateResponse(HttpStatus.OK, true, "success", trans);
    }

    @InterceptQuestions
    @PostMapping("initiate/{type}")
    public ResponseEntity<Object> Withdrawal(@RequestBody AccountMvtDto dto, @AuthenticationPrincipal Subscriptions subscriber, @PathVariable String type) throws SQLException, ResourceNotFoundException {
        MobilePayment initiatedPayment;
        MobilePayment mobilePayment ;
        if(type.equals("withdrawal")) {
            mobilePayment = MobilePayment.AccountMvtToMobilePayWithdraw(dto, subscriber);
            mobilePayment.setStatut("INITIATED");
        } else if(type.equals("deposit")) {
             mobilePayment = MobilePayment.AccountMvtToMobilePayDeposit(dto, subscriber);
            mobilePayment.setStatut("INITIATED");
        } else  {
            throw new ResourceNotFoundException("invalid_operation");
        }

        AccountEntityDto accountInfo = accountService.findClientAccounts(dto.getAccountId()).stream()
                .findFirst()
                .orElseThrow(() -> new ResourceNotFoundException("invalid_account"));

        initiatedPayment = mobilePaymentService.insertionMobilePayment(mobilePayment);
        OtpEntity params = OtpEntity.builder()
                .guid(initiatedPayment.getUuid())
                .destination(subscriber.getEmail())
                .role(OtpEnum.VALIDATE_TRANSACTION)
                .transport(OtpChanel.MAIL)
                .build();

        initiatedPayment.setName(accountInfo.getClientName());
        initiatedPayment.setAccountType(accountInfo.getAccountName());

        List<Object> payloads = new ArrayList<>();
        payloads.add(initiatedPayment);
        payloads.add(UserDto.CreateSubscriberClientDto.modelToDao(subscriber));
       CustomerVerification verificationObject =  otpService.GenerateAndSend(params,payloads, subscriber);

        return ResponseHandler.generateResponse(HttpStatus.OK, false, "success", verificationObject);

    }

    public ResponseEntity<Object> validatedInitiatedOperation( Subscriptions subscriber,  String operationUuid) throws Exception {
        MobilePayment initiatedPayment = mobilePaymentService.getPaymentBytUuidAndClient(operationUuid, subscriber.getClientMatricul())
                .stream()
                .findFirst()
                .orElseThrow(() -> new ResourceNotFoundException("invalid_transaction"));

        if(!initiatedPayment.getStatut().trim().equals("INITIATED")) throw new ResourceNotFoundException("invalid_transaction");

        if(initiatedPayment.getType().equals("DEPOSIT")) {
            ChannelCode channelCode;

            switch (initiatedPayment.getTypeOperation()) {
                case "MTNRET" -> channelCode = ChannelCode.CHANNEL_MTN_CM;
                case "OMRETR" -> channelCode = ChannelCode.CHANNEL_OM_CM;
                default -> {
                    throw new ResourceNotFoundException("INVALID  OPERATION TYPE");
                }
            }
        InitPayment initPayment = InitPayment.AccountMvnToInitPay(initiatedPayment, subscriber);

        initPayment.setType(PaymentType.cash_collect);
        initPayment.setChannel(channelCode);
        initPayment.setReference(initiatedPayment.getUuid());

        PaymentDto result = paymentService.initiatePayment(initPayment);
        initiatedPayment.setPaymentGatewaysUuid(result.getData().getTransaction().getUuid());
        initiatedPayment.setStatut("PENDING");
        mobilePaymentService.updateMobilePayment(initiatedPayment);

        //                FIN ESSAI CALLBACK
        ExecutePayment execute = new ExecutePayment();
        execute.setSchema_type("CM_MOBILE_MONEY_SCHEMA");
        MomoSchemaType schema = new MomoSchemaType();
        schema.setPhoneNumber("237" + initiatedPayment.getTelephone());
        execute.setSchema(schema);

        PaymentDto executeResponse = paymentService.executePayment(execute, result.getData().getTransaction().getUuid());
        String status = executeResponse.getData().getTransaction().getStatus().toString();

        if (status.trim().equals("SUCCESS")) {
            initiatedPayment.setPaymentGatewaysUuid(executeResponse.getData().getTransaction().getUuid());
            // DO THE ACCOUNT MOVEMENT
//            initiatedPayment.setStatut("COMPL");
            mobilePaymentService.updateMobilePayment(initiatedPayment);
            return ResponseHandler.generateResponse(HttpStatus.OK, false, "success", initiatedPayment);
        }

        if (status.trim().equals("PENDING") || status.trim().equals("WAITING_FOR_PAYMENT")) {
            initiatedPayment.setPaymentGatewaysUuid(executeResponse.getData().getTransaction().getUuid());
            mobilePaymentService.updateMobilePayment(initiatedPayment);
            return ResponseHandler.generateResponse(HttpStatus.OK, false, "pending", initiatedPayment);
        }

        System.out.println(executeResponse.toString());
        initiatedPayment.setCallBackReceive(true);
        initiatedPayment.setStatut(status);
        mobilePaymentService.updateMobilePayment(initiatedPayment);
            return ResponseHandler.generateResponse(HttpStatus.OK, false, "success", initiatedPayment);
        }
        else if (initiatedPayment.getType().equals("WITHDRAWAL")) {
            ChannelCode channelCode;
            switch (initiatedPayment.getTypeOperation()) {
                case "MOMODE" -> channelCode = ChannelCode.CHANNEL_MTN_CM;
                case "OMDEPO" -> channelCode = ChannelCode.CHANNEL_OM_CM;
                case "MTNCRE" -> channelCode = ChannelCode.CHANNEL_MTN_AIRTIME_CM;
                case "ORCRED" -> channelCode = ChannelCode.CHANNEL_ORANGE_AIRTIME_CM;
                case "NECRED" -> channelCode = ChannelCode.CHANNEL_NEXTTEL_AIRTIME_CM;
                case "ENEOBI" -> channelCode = ChannelCode.CHANNEL_ENEO_BILLS_CM;
                case "WATERBI" -> channelCode = ChannelCode.CHANNEL_CAMWATER_BILLS_CM;
                case "CANALB" -> channelCode = ChannelCode.CHANNEL_CANAL_PLUS_BILLS_CM;
                default -> {
                    throw new ResourceNotFoundException("INVALID  OPERATION TYPE");
                }
            }

        InitPayment initPayment = InitPayment.AccountMvnToInitPay(initiatedPayment, subscriber);

        initPayment.setType(PaymentType.payout);
        initPayment.setChannel(channelCode);
        initPayment.setReference(initiatedPayment.getUuid());

        PaymentDto result = paymentService.initiatePayment(initPayment);
        initiatedPayment.PaymentGatewaysUuid = result.getData().getTransaction().getUuid();
        initiatedPayment.setStatut("PENDING");
        mobilePaymentService.updateMobilePayment(initiatedPayment);

        AccountEntityDto accountInfo = accountService.findClientAccounts(initiatedPayment.getCpteJumelle())
                .stream()
                .findFirst()
                .orElseThrow(() -> new ResourceNotFoundException("invalid_transaction"));

        AccountMvtDto accountMovementDto =  AccountMvtDto.builder()
                .accountId(initiatedPayment.getCpteJumelle())
                .phoneNumber(Integer.parseInt(accountInfo.getMobile()))
                .amount(initiatedPayment.getMontant())
                .sens(2)
                .typeOp(initiatedPayment.getTypeOperation())
                .date(initiatedPayment.getDate())
                .description(initiatedPayment.description)
                .ids(initiatedPayment.getUuid()).build();

        AccountMvtDto accountMovement = mobilePaymentService.account_mvt(accountMovementDto);
        initiatedPayment.setTrxNumber(accountMovement.getPc_OutID());
        mobilePaymentService.updateMobilePayment(initiatedPayment);


        ExecutePayment execute = new ExecutePayment();
        execute.setSchema_type("CM_MOBILE_MONEY_SCHEMA");
        MomoSchemaType schema = new MomoSchemaType();
        schema.setPhoneNumber("237" + initiatedPayment.getTelephone());
        execute.setSchema(schema);

        PaymentDto executeResponse = paymentService.executePayment(execute, result.getData().getTransaction().getUuid());

        String status = executeResponse.getData().getTransaction().getStatus().toString();
        initiatedPayment.setStatut(status);

        if (status.trim().equals("PENDING") || status.trim().equals("WAITING_FOR_PAYMENT") ) {
            mobilePaymentService.updateMobilePayment(initiatedPayment);
            return ResponseHandler.generateResponse(HttpStatus.OK, false, "pending", initiatedPayment);
        }

        if ( status.trim().equals("SUCCESS")) {
            mobilePaymentService.updateMobilePayment(initiatedPayment);
            initiatedPayment.setCallBackReceive(true);
            return ResponseHandler.generateResponse(HttpStatus.OK, false, "success", initiatedPayment);
        }

        AccountCallback accountCallback = new AccountCallback();
        accountCallback.setAccount(initiatedPayment.getCpteJumelle());
        accountCallback.setTrxNumber(initiatedPayment.getTrxNumber());
        accountCallback.setTelephone(initiatedPayment.getTelephone());

        mobilePaymentService.account_callback(accountCallback);

        initiatedPayment.setCallBackReceive(true);
        mobilePaymentService.updateMobilePayment(initiatedPayment);

        return ResponseHandler.generateResponse(HttpStatus.OK, true, "FAILED PAYMENT", initiatedPayment);
        }

        throw new ResourceNotFoundException("invalid_transaction");
    }

    @PostMapping("searchPayable")
    public ResponseEntity<Object> SearchPayable(@RequestBody SearchDataBillDto bill)  {
        ChannelCode channelCode;

        switch (bill.getTypeOp()) {
            case "ENEOBI" -> channelCode = ChannelCode.CHANNEL_ENEO_BILLS_CM;
            case "WATERBI" -> channelCode = ChannelCode.CHANNEL_CAMWATER_BILLS_CM;
            case "CANALB" -> channelCode = ChannelCode.CHANNEL_CANAL_PLUS_BILLS_CM;
            default -> {
                return ResponseHandler.generateResponse(HttpStatus.OK, false, "success", "INVALID TYPE OPERATION");
            }
        }

        PayableResponse response = paymentService.searchpayable(channelCode, bill.getId());
        return ResponseHandler.generateResponse(HttpStatus.OK, false, "success", response.getData().getItems());

    }

    @PostMapping(("getBillingOption"))
    public ResponseEntity<Object> BillingOptionVAT(@RequestBody() BillingListDto json ) throws Exception {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd/MM/yyyy");
        String date = simpleDateFormat.format(new Date());
        json.setPd_ServerDate(date);
        json.setLanguage("En");
        BillingListDto item = accountService.amountBillingOptionWithVAT(json);
       return ResponseHandler.generateResponse(HttpStatus.OK, false, "success", item);
    }

    @PostMapping("callBack/payment")
    public ResponseEntity<Object> call_back(String json, @RequestHeader("x-hash") String key) throws Exception {

        System.out.println(json);
        ObjectMapper mapper = new ObjectMapper();
        JSONObject jsonObject =new JSONObject();

        // convert JSON string to Book object
        TransactionData transactionData = mapper.readValue(json, TransactionData.class);
        Transaction transaction = transactionData.getTransaction();
        String statut = transaction.getStatus().toString();
        if (transaction.getUuid() == null) {
            jsonObject.put("status", 0);
            jsonObject.put("message","INVALID REQUEST" );
            sseController.sendTransactionEvent(statut,"status");
            return ResponseHandler.generateResponse(HttpStatus.OK, false, "success", jsonObject);
        }
        MobilePayment pay = mobilePaymentService.get_paymentUuid(transaction.getUuid())
                .stream()
                .findFirst()
                .orElseThrow();
        if (pay.getClient() == null) {
            jsonObject.put("status", 0);
            jsonObject.put("message","PAYMENT NOT FOUND" );

            sseController.sendTransactionEvent(statut,"status");

            return ResponseHandler.generateResponse(HttpStatus.OK, false, "success", jsonObject);

        }
        if (pay.getCallBackReceive()) {
            jsonObject.put("status", 0);
            jsonObject.put("message","INVALID PAYMENT" );

            sseController.sendTransactionEvent(statut,"status");

            return ResponseHandler.generateResponse(HttpStatus.OK, false, "success", jsonObject);
        }

        if (pay.getStatut().trim().equals("FAILED") || pay.getStatut().trim().equals("CANCELLED") || pay.getStatut().trim().equals("SUCCESS")) {
            jsonObject.put("status", 0);
            jsonObject.put("message","INVALID PAYMENT STATUT" );

            sseController.sendTransactionEvent(statut,"status");

            return ResponseHandler.generateResponse(HttpStatus.OK, false, "success", jsonObject);
        }

        pay.setCallBackReceive(true);
        pay.setStatut(statut);
        mobilePaymentService.updateMobilePayment(pay);
        AccountMvtDto transfer = new AccountMvtDto();
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd/MM/yyyy");
        String date = simpleDateFormat.format(new Date());
        transfer.setAccountId(pay.getCpteJumelle());
        transfer.setPhoneNumber(Integer.parseInt(pay.getTelephone()));
        transfer.setAmount(pay.getMontant());
        transfer.setDate(date);
        transfer.setIds("");
        transfer.setTypeOp(pay.getTypeOperation());
        //
        AccountCallback repay = new AccountCallback();
        repay.setAccount(pay.getCpteJumelle());
        repay.setTrxNumber(pay.getTrxNumber());
        repay.setTelephone(pay.getTelephone());
        // teste l''envoie du sms dans le callback

        if ((statut.trim().equals("FAILED") || statut.trim().equals("CANCELLED")) && pay.Type.trim().equals("WITHDRAWAL")) {
            transfer.setSens(2);
            transfer.setDescription("REPAYMENT");
            mobilePaymentService.account_callback(repay);
            jsonObject.put("status", 0);
            jsonObject.put("message","PAYMENT REFUNDED" );

            operationCompleted.set(true);
            sseController.sendTransactionEvent(statut,"status");

            return ResponseHandler.generateResponse(HttpStatus.OK, false, "success", jsonObject);
        } else if (statut.trim().equals("SUCCESS") && pay.Type.trim().equals("DEPOSIT")) {
            transfer.setSens(1);
            transfer.setDescription(
                    transactionData.getTransaction()
                    .getPaymentMethod().getName().concat(" Deposit from ").
                    concat(transactionData.getTransaction().getRecipient()));

            AccountMvtDto item = mobilePaymentService.account_mvt(transfer);
            pay.TrxNumber=item.getPc_OutID();
            mobilePaymentService.updateMobilePayment(pay);
            if (item.getPc_OutLECT() != 0) {
                JSONObject jsonObject1 = new JSONObject();
                jsonObject.put("status", item.getPc_OutLECT());
                jsonObject.put("message", item.getPc_OutMSG());
                jsonObject.put("code", item.getPc_OutID());
                operationCompleted.set(true);
                return ResponseHandler.generateResponse(HttpStatus.OK, false, "success", jsonObject1);
            }
            jsonObject.put("status", 0);
            jsonObject.put("message","PAYMENT COMPLETED" );

            operationCompleted.set(true);
            sseController.sendTransactionEvent(statut,"status");

            return ResponseHandler.generateResponse(HttpStatus.OK, false, "success", jsonObject);
        } else {
            jsonObject.put("status", 0);
            jsonObject.put("message","OK" );

            operationCompleted.set(true);
            sseController.sendTransactionEvent(statut,"status");

            return ResponseHandler.generateResponse(HttpStatus.OK, false, "success", jsonObject);

        }
    }

    @GetMapping(value = "/transactionStatus/{uuid}", produces = "text/event-stream")
    public Flux<ServerSentEvent<String>> sendEventStream(@PathVariable String uuid,  @AuthenticationPrincipal Subscriptions subscriber) throws Exception {
        JSONObject jsonObject =new JSONObject();
        if (operationCompleted.get()) {
            MobilePayment pay = mobilePaymentService.get_paymentUuid(uuid)
                    .stream()
                    .findFirst()
                    .orElseThrow(() -> new ResourceNotFoundException("invalid_transaction"));

            if (!pay.getClient().equals(subscriber.getClientMatricul())) {
                jsonObject.put("status", 0);
                jsonObject.put("message","PAYMENT NOT FOUND" );
                operationCompleted.set(false);
                return Flux.just(ServerSentEvent.<String>builder()
                                .id("1")
                                .event("message")
                                .data("PAYMENT_NOT_FOUND")
                                .build())
                        .concatWith(Flux.empty());
            }
            operationCompleted.set(false);
            return Flux.just(ServerSentEvent.<String>builder()
                            .id("1")
                            .event("message")
                            .data(pay.getStatut())
                            .build())
                    .concatWith(Flux.empty());

        }
        return Flux.empty();
    }


}


