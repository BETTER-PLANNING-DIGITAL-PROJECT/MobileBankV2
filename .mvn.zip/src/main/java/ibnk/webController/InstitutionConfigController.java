package ibnk.webController;

import ibnk.dto.BankingDto.MobileBankConfigDto;
import ibnk.models.InstitutionConfig;
import ibnk.models.NotificationTemplate;
import ibnk.models.client.SecurityQuestions;
import ibnk.repository.ClientSecurityQuestionRepository;
import ibnk.service.BankingService.AccountService;
import ibnk.service.InstitutionConfigService;
import ibnk.service.QuestionService;
import ibnk.tools.ResponseHandler;
import ibnk.tools.error.ResourceNotFoundException;
import ibnk.tools.error.UnauthorizedUserException;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.sql.SQLException;
import java.util.List;

@RequiredArgsConstructor
@RestController
@CrossOrigin
@RequestMapping("/api/v1/admin/instConfig")
public class InstitutionConfigController {

    private final InstitutionConfigService institutionConfigService;
    private final AccountService accountService;
    private final QuestionService questionService;
    private final ClientSecurityQuestionRepository clientSecurityQuestionRepository;

    @PutMapping("update")
    public ResponseEntity<Object> updateInstConfig(@RequestBody InstitutionConfig dto) throws UnauthorizedUserException, SQLException, ResourceNotFoundException {
        String instConfig = institutionConfigService.updateInstitutionConfig(dto);
        return ResponseHandler.generateResponse(HttpStatus.OK, true, "Success", instConfig);
    }

    @GetMapping("listInstConfig")
    public ResponseEntity<Object> listInstConfig() throws ResourceNotFoundException {
        InstitutionConfig institutionConfig = institutionConfigService.listConfig();
        return ResponseHandler.generateResponse(HttpStatus.OK, true, "Success", institutionConfig);

    }
    @GetMapping("listMobileConfig")
    public ResponseEntity<Object> listMobileBankConfig() throws SQLException {
        List<MobileBankConfigDto> mobileBankConfigDto = accountService.findMbConfig();
        return ResponseHandler.generateResponse(HttpStatus.OK, true, "Success", mobileBankConfigDto);

    }

    @GetMapping("listQuestions")
    public ResponseEntity<Object> listQuestion() {
        List<SecurityQuestions> securityQuestions = questionService.listAllQuestions();
        securityQuestions.forEach((q -> {
            q.setQuestionCount(clientSecurityQuestionRepository.countBySecurityQuestions(q));
        }));
        return ResponseHandler.generateResponse(HttpStatus.OK, true, "Success", securityQuestions);
    }

    @PostMapping("addQuestion")
    public ResponseEntity<Object> addQuestions(@RequestBody SecurityQuestions dao) throws UnauthorizedUserException, SQLException, ResourceNotFoundException {
        String securityQuestions = questionService.saveSecurityQuestions(dao);
        return ResponseHandler.generateResponse(HttpStatus.OK, true, "Success", securityQuestions);
    }

    @DeleteMapping("deleteQuestion/{id}")
    public ResponseEntity<Object> deleteQuestions(@PathVariable Long id) throws UnauthorizedUserException, SQLException, ResourceNotFoundException {
        String securityQuestions = questionService.deleteSecurityQuestion(id);
        return ResponseHandler.generateResponse(HttpStatus.OK, true, "Success", securityQuestions);
    }

    @PutMapping("update-notification-template")
    public ResponseEntity<Object> updateNotification(@RequestBody NotificationTemplate dto) throws ResourceNotFoundException {
        String response = institutionConfigService.UpdateNotifTemplate(dto.getId(),dto);
        return ResponseHandler.generateResponse(HttpStatus.OK, true, "Success", response);
    }
    @DeleteMapping("delete/{id}")
    public ResponseEntity<Object>deleteNotification(@PathVariable("id") Long id) throws ResourceNotFoundException {
        String response = institutionConfigService.deleteNotifById(id);
        return ResponseHandler.generateResponse(HttpStatus.OK, true, "Success", response);

    }
    @GetMapping("list-templates")
    public ResponseEntity<Object> listNotification()  {
        List<NotificationTemplate> response = institutionConfigService.listNotifTemplate();
        return ResponseHandler.generateResponse(HttpStatus.OK, true, "Success", response);

    }
}
