package ibnk.webController;

import ibnk.dto.SubscriptionDao;
import ibnk.dto.UserDto;
import ibnk.models.UserEntity;
import ibnk.models.client.SecurityQuestions;
import ibnk.service.QuestionService;
import ibnk.tools.ResponseHandler;
import ibnk.tools.error.ResourceNotFoundException;
import ibnk.tools.error.UnauthorizedUserException;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.sql.SQLException;
import java.util.List;

@RequiredArgsConstructor
@RestController
@RequestMapping("/api/v1/admin/question")
public class SecurityQuestionsController {
    private final QuestionService questionService;
}
