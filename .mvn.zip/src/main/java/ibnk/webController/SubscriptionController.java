package ibnk.webController;


import ibnk.dto.SubscriptionDao;
import ibnk.dto.UserDto;
import ibnk.models.UserEntity;
import ibnk.service.BankingService.AccountService;
import ibnk.service.CustomerService;
import ibnk.tools.ResponseHandler;
import ibnk.tools.error.ResourceNotFoundException;
import ibnk.tools.error.UnauthorizedUserException;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.sql.SQLException;

@RequiredArgsConstructor
@RestController
@CrossOrigin
@RequestMapping("/api/v1/admin/subscription")
public class SubscriptionController {
    private final CustomerService customerService;

    @PostMapping("add")
    public ResponseEntity<Object> subscribe(@AuthenticationPrincipal UserEntity user, @RequestBody SubscriptionDao dao) throws UnauthorizedUserException, SQLException, ResourceNotFoundException {
        UserDto.CreateSubscriberClientDto cus = customerService.Subscribe(dao, user);
        return ResponseHandler.generateResponse(HttpStatus.OK, true, "Success", cus);
    }

    @GetMapping("/listAll")
    public ResponseEntity<Object> ListAllSubscriptions() {
        var subs = customerService.AllSubscribers();
        return ResponseHandler.generateResponse(HttpStatus.OK, false, "success", subs);
    }


}


