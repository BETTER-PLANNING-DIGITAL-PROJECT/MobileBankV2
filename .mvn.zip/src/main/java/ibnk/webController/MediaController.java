package ibnk.webController;

import ibnk.models.Media;
import ibnk.models.enums.MediaType;
import ibnk.service.MediaService;
import ibnk.tools.ResponseHandler;
import ibnk.tools.TOOLS;
import ibnk.tools.error.ResourceNotFoundException;
import ibnk.tools.nexaConfig.EmailService;
import ibnk.tools.response.GlobalResponse;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.server.ResponseStatusException;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.util.Objects;
import java.util.Optional;

@RequiredArgsConstructor
@RestController
@CrossOrigin
@RequestMapping("/api/v1/admin/media")
public class MediaController {
    private final MediaService mediaService;
    private final EmailService emailService;

    @PostMapping("/upload")
    @Transactional
    public ResponseEntity<Object> uploadImage(
            @RequestParam("file") MultipartFile file
//            @ModelAttribute UploadMediaDto dto,
//            @AuthenticationPrincipal UserEntity user
    ) throws IOException {
        Object mediaDetails = null;
        // Assert file exists
        if (file.isEmpty()) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "File is missing");
        }
        System.out.println(file.getOriginalFilename());

        // Convert MultipartFile to a File object
        File convertedFile = new File(Objects.requireNonNull(file.getOriginalFilename()));
        try (FileOutputStream fos = new FileOutputStream(convertedFile)) {
            fos.write(file.getBytes());
        } catch (IOException e) {
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Error saving file");
        }

        // Create a new Media object and save it
        Media media = new Media();
        media.setFileName(file.getOriginalFilename());
        media.setSize(file.getSize());
//        media.setOwner(user);
        media.setImg(Files.readAllBytes(convertedFile.toPath()));
//        media.setRole(dto.getRole());
        media.setType(MediaType.IMAGE.name());
        media.setOriginalFileName(file.getOriginalFilename());
        media.setPhoto(convertedFile.toPath().toString());
        media.setExtension(TOOLS.getFileExtension(file.getOriginalFilename()));
        String message = null;
        boolean error = false;
        if (media.getUuid() == null) {
            mediaDetails = mediaService.save(media);
            message = "saved";
            error = true;
        }
//        Media savedMedia = mediaService.save(media);
//        System.out.println(mediaDetails);

        GlobalResponse<Object, String> response = new GlobalResponse<>(mediaDetails, message);
        return ResponseHandler.generateResponse(HttpStatus.OK, error, "success", response);
    }

    @GetMapping("/listImage/{uuid}")
    public ResponseEntity<Object> listImage(@PathVariable("uuid") String uuid){
       Optional<Media> response = mediaService.findByUuid(uuid);
        return ResponseHandler.generateResponse(HttpStatus.OK, true, "success", response.get().getImg());

    }
    @PostMapping("/sendEmail")
    public ResponseEntity<Object> sendEmail() throws ResourceNotFoundException {

        emailService.sendSimpleMessage("benzeezmokom@gmail.com","TEST",

                "<body>\n" +
                "    <div style=\"font-family: Arial, sans-serif;\">\n" +
                "\n" +
                "        <h2>Welcome to Our Newsletter!</h2>\n" +
                "\n" +
                "        <p>Dear Subscriber,</p>\n" +
                "\n" +
                "        <p>Thank you for subscribing to our newsletter. We are thrilled to have you on board!</p>\n" +
                "\n" +
                "        <p>Here's what you can expect from our newsletter:</p>\n" +
                "\n" +
                "        <ul>\n" +
                "            <li>Exclusive offers and promotions</li>\n" +
                "            <li>Latest updates on our products and services</li>\n" +
                "            <li>Useful tips and tricks</li>\n" +
                "        </ul>\n" +
                "\n" +
                "        <p>We promise to deliver valuable content straight to your inbox. Stay tuned!</p>\n" +
                "\n" +
                "        <p>Best Regards,<br> The Newsletter Team</p>\n" +
                "\n" +
                "    </div>\n" +
                "</body>\n");
        return ResponseHandler.generateResponse(HttpStatus.OK, true, "success","Success");
    }
//    String message,String subject,String to

}
