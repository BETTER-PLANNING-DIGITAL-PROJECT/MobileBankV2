package ibnk.models.enums;

public enum PathType {
    MODULE ,
    MENU
}
