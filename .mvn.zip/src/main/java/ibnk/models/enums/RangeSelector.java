package ibnk.models.enums;

public enum RangeSelector {
    THIS_MONTH,
    PREVIOUS_MONTH,
    PREVIOUS_QUARTER,

    DATE_RANGE
}
