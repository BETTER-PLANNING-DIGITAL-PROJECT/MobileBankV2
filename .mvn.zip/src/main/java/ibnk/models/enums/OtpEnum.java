package ibnk.models.enums;

import lombok.Data;


public enum OtpEnum {
    LOGIN,
    RESET_PASSWORD,
    FIRST_LOGIN,
    REGISTRATION_REQUEST,
    VALIDATE_TRANSACTION
}
