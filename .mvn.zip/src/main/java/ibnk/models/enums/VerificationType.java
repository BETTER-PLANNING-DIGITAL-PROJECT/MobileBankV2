package ibnk.models.enums;

public enum VerificationType {
    OTP,
    SECURITY_QUESTION
}
