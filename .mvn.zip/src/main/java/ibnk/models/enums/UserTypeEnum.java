package ibnk.models.enums;

public enum UserTypeEnum {
    ADMIN,
    CLIENT
}
