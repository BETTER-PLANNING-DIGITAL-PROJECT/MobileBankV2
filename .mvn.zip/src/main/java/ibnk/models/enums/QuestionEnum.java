package ibnk.models.enums;

public enum QuestionEnum {
    AUTO,
    MANUAL
}
