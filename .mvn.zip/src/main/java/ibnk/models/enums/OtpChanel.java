package ibnk.models.enums;

public enum OtpChanel {
    SMS,
    MAIL,
    BOTH
}
