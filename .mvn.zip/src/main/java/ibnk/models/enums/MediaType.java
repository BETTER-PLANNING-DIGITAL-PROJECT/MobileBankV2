package ibnk.models.enums;

public enum MediaType {
    IMAGE
}
