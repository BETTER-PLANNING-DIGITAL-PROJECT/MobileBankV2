package ibnk.models.enums;



public enum EventCode {
    FIRST_LOGIN,
    VALIDATE_TRANSACTION,
    INTERNET_BAKING_SUBSCRIPTION,
    LOGIN,
    RESET_PASSWORD,
    REGISTRATION_REQUEST
}
