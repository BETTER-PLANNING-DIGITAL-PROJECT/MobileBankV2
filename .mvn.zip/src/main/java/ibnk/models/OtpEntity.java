package ibnk.models;

import com.fasterxml.jackson.annotation.JsonIgnore;
import ibnk.models.enums.OtpChanel;
import ibnk.models.enums.OtpEnum;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.RequiredArgsConstructor;
import org.hibernate.annotations.UuidGenerator;

import java.time.LocalDateTime;
import java.util.UUID;

@Data
@Builder
@AllArgsConstructor
@RequiredArgsConstructor
@Entity
@Table(name = "_otp")
public class OtpEntity {
    @Id
    @JsonIgnore
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @UuidGenerator
    @Column(unique = true,nullable = false)
    private String uuid;

    @Column(nullable = false)
    private String guid;

    @Column(nullable = false)
    private Long minBeforeExpire;

    @JsonIgnore
    private Long otp;

    private String destination;

    @Enumerated(EnumType.STRING)
    private OtpEnum role;

    @JsonIgnore
    private Boolean sent;

    @Enumerated(EnumType.STRING)
    private OtpChanel transport;

    @JsonIgnore
    private Boolean used;

    private LocalDateTime expiresAt;
    @PrePersist
    public void setUuid(){
        this.uuid = UUID.randomUUID().toString();
    }
}
