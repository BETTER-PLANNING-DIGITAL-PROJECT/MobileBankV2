package ibnk;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InternetBankingApplicationTests {

	@Test
	void contextLoads() {
	}

}
